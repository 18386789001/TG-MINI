package com.jump.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.ShareRecord;
import com.jump.po.ShareInfoVo;

/**
 * 分享记录
 *
 * @date 2024-07-06 03:47:29
 */
public interface ShareRecordService extends IService<ShareRecord> {

}
