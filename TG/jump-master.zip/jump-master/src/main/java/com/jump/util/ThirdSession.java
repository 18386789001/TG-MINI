package com.jump.util;

import lombok.Data;

import java.io.Serializable;

@Data
public class ThirdSession implements Serializable {

    private String wxUserId;
    private String appId;
    private String sessionKey;
    private String openId;
    private String userId;
}
