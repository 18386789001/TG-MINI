package com.jump.task;

import com.jump.service.UserInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class UserHpTask {

    @Autowired
    private UserInfoService userInfoService;


    @Scheduled(cron = "0 0 * * * ?")
    public void incHp() {
        userInfoService.incHp();
//        LocalDateTime now=LocalDateTime.now();
//        System.out.println("spring task 这是定时任务，时间是："+pattern.format(now));
    }


    @Scheduled(cron = "0 0 0 * * ?")
    public void reset() {
        userInfoService.resetHp();
//        LocalDateTime now=LocalDateTime.now();
//        System.out.println("spring task 这是定时任务，时间是："+pattern.format(now));
    }

}
