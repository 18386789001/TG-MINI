package com.jump.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.annotation.ApiLogin;
import com.jump.entity.*;
import com.jump.mapper.TaskRecordMapper;
import com.jump.po.TaskRecordPo;
import com.jump.service.*;
import com.jump.util.ThirdSession;
import com.jump.util.ThirdSessionHolder;
import javafx.concurrent.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.sql.Wrapper;
import java.time.LocalDateTime;

/**
 * 任务完成记录
 *
 * @date 2024-06-30 21:11:36
 */
@Service
public class TaskRecordServiceImpl extends ServiceImpl<TaskRecordMapper, TaskRecord> implements TaskRecordService {

    @Autowired
    private PostInfoService postInfoService;
    @Autowired
    private MemeInfoService memeInfoService;
    @Autowired
    private UserInfoService userInfoService;
    @Autowired
    private TaskInfoService taskInfoService;

    @Override
    @Transactional
    public Boolean add(TaskRecordPo taskRecordPo) {
        TaskRecord taskRecord1 = baseMapper.selectOne(Wrappers.<TaskRecord>lambdaQuery()
                .eq(TaskRecord::getTaskId, taskRecordPo.getTaskId())
                .eq(TaskRecord::getUserId, ThirdSessionHolder.getUserId()));
        if (taskRecord1 != null) {
            return Boolean.TRUE;
        }
        if (taskRecordPo.getTaskType().equals("6") ||
                taskRecordPo.getTaskType().equals("7") ||
                taskRecordPo.getTaskType().equals("8")||
                taskRecordPo.getTaskType().equals("9")) {
            PostInfo postInfo = new PostInfo();
            postInfo.setPostContent(taskRecordPo.getPostContent());
            postInfo.setImgUrl(taskRecordPo.getImgUrl());
            postInfo.setType(taskRecordPo.getTaskType());
            postInfo.setCreateTime(LocalDateTime.now());
            postInfo.setUpdateTime(LocalDateTime.now());
            postInfo.setUserId(ThirdSessionHolder.getUserId());
            postInfo.setTaskId(taskRecordPo.getTaskId());
            postInfoService.save(postInfo);
        }
        TaskRecord taskRecord = new TaskRecord();
        taskRecord.setStatus("1");
        taskRecord.setUserId(ThirdSessionHolder.getUserId());
        taskRecord.setCreateTime(LocalDateTime.now());
        taskRecord.setTaskId(taskRecordPo.getTaskId());
        return super.save(taskRecord);

    }


    @Override
    public void handel(Long id) {
        System.out.println("加入群聊：" + id);
        UserInfo userInfo = userInfoService.getOne(Wrappers.<UserInfo>lambdaQuery().eq(UserInfo::getChatId, id));
        if (userInfo != null) {
            TaskInfo taskInfo = taskInfoService.getOne(Wrappers.<TaskInfo>lambdaQuery().eq(TaskInfo::getType, "1"));
            TaskRecord taskRecord = baseMapper.selectOne(Wrappers.<TaskRecord>lambdaQuery()
                    .eq(TaskRecord::getTaskId, taskInfo.getId())
                    .eq(TaskRecord::getUserId, userInfo.getId()));
            if (taskRecord != null) {
                if (taskRecord.getStatus().equals("0")) {
                    taskRecord.setStatus("2");
                    baseMapper.updateById(taskRecord);
                    userInfo.setPoints(userInfo.getPoints() + taskInfo.getPoints());
                    userInfoService.updateById(userInfo);
                }
            }
        }
    }

    @Override
    public void handMessage(Long id) {
        System.out.println("加入群聊：" + id);
        UserInfo userInfo = userInfoService.getOne(Wrappers.<UserInfo>lambdaQuery().eq(UserInfo::getChatId, id));
        if (userInfo != null) {
            TaskInfo taskInfo = taskInfoService.getOne(Wrappers.<TaskInfo>lambdaQuery().eq(TaskInfo::getType, "2"));
            TaskRecord taskRecord = baseMapper.selectOne(Wrappers.<TaskRecord>lambdaQuery()
                    .eq(TaskRecord::getTaskId, taskInfo.getId())
                    .eq(TaskRecord::getUserId, userInfo.getId()));
            if (taskRecord != null) {
                if (taskRecord.getStatus().equals("0")) {
                    taskRecord.setStatus("2");
                    baseMapper.updateById(taskRecord);
                    userInfo.setPoints(userInfo.getPoints() + taskInfo.getPoints());
                    userInfoService.updateById(userInfo);
                }
            }
        }
    }


    @Override
    public Boolean joinChannel(TaskRecordPo taskRecordPo) {
        if (taskRecordPo.getTaskType().equals("1")) {
            TaskRecord taskRecord = super.getOne(Wrappers.<TaskRecord>lambdaQuery()
                    .eq(TaskRecord::getTaskId, taskRecordPo.getTaskId())
                    .eq(TaskRecord::getUserId, ThirdSessionHolder.getUserId()));
            if (taskRecord != null) {
                taskRecord.setStatus("2");
                UserInfo userInfo = userInfoService.getById(ThirdSessionHolder.getUserId());
                TaskInfo taskInfo = taskInfoService.getById(taskRecord.getTaskId());
                userInfo.setPoints(userInfo.getPoints() + taskInfo.getPoints());
                userInfoService.updateById(userInfo);
                super.updateById(taskRecord);
            }
        }
        return Boolean.TRUE;
    }

    @Override
    public Boolean followX(TaskRecordPo taskRecordPo) {
        if (taskRecordPo.getTaskType().equals("3")) {
            TaskRecord taskRecord = super.getOne(Wrappers.<TaskRecord>lambdaQuery()
                    .eq(TaskRecord::getTaskId, taskRecordPo.getTaskId())
                    .eq(TaskRecord::getUserId, ThirdSessionHolder.getUserId()));
            if (taskRecord != null) {
                taskRecord.setStatus("2");
                UserInfo userInfo = userInfoService.getById(ThirdSessionHolder.getUserId());
                TaskInfo taskInfo = taskInfoService.getById(taskRecord.getTaskId());
                userInfo.setPoints(userInfo.getPoints() + taskInfo.getPoints());
                userInfoService.updateById(userInfo);
                super.updateById(taskRecord);
            }
        }
        return Boolean.TRUE;
    }


    @Override
    public Boolean confirmCompletion(TaskRecordPo taskRecordPo) {
        TaskRecord taskRecord = super.getOne(Wrappers.<TaskRecord>lambdaQuery()
                .eq(TaskRecord::getTaskId, taskRecordPo.getTaskId())
                .eq(TaskRecord::getUserId, ThirdSessionHolder.getUserId()));
        if (taskRecord != null) {
            if (taskRecord.getStatus().equals("1")) {
                taskRecord.setStatus("2");
                UserInfo userInfo = userInfoService.getById(ThirdSessionHolder.getUserId());
                TaskInfo taskInfo = taskInfoService.getById(taskRecord.getTaskId());
                userInfo.setPoints(userInfo.getPoints() + taskInfo.getPoints());
                userInfoService.updateById(userInfo);
                super.updateById(taskRecord);
            }

        }
        return Boolean.TRUE;
    }
}
