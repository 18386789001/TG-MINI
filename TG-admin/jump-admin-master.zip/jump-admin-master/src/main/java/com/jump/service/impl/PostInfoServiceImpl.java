package com.jump.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.PostInfo;
import com.jump.entity.TaskInfo;
import com.jump.entity.TaskRecord;
import com.jump.entity.UserInfo;
import com.jump.mapper.PostInfoMapper;
import com.jump.po.PostInfoPo;
import com.jump.service.PostInfoService;
import com.jump.service.TaskInfoService;
import com.jump.service.TaskRecordService;
import com.jump.service.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PostInfoServiceImpl extends ServiceImpl<PostInfoMapper, PostInfo> implements PostInfoService {

    @Autowired
    private TaskInfoService taskInfoService;
    @Autowired
    private TaskRecordService taskRecordService;
    @Autowired
    private UserInfoService userInfoService;


    @Override
    public Boolean verify(PostInfoPo postInfoPo) {
        PostInfo postInfo = baseMapper.selectById(postInfoPo.getId());
        if (postInfo.getStatus().equals("0")) {

            postInfo.setStatus(postInfoPo.getStatus());
            if (postInfoPo.getStatus().equals("1")) {
                if (!postInfo.getType().equals("7") &&
                        !postInfo.getType().equals("8")
                        && !postInfo.getType().equals("9")) {
                    TaskRecord taskRecord = taskRecordService.getOne(Wrappers.<TaskRecord>lambdaQuery()
                            .eq(TaskRecord::getUserId, postInfo.getUserId())
                            .eq(TaskRecord::getTaskId, postInfo.getTaskId()));
                    taskRecord.setStatus("2");
                    taskRecordService.updateById(taskRecord);
                }
                TaskInfo taskInfo = taskInfoService.getById(postInfo.getTaskId());
                UserInfo userInfo = userInfoService.getById(postInfo.getUserId());
                userInfo.setPoints(userInfo.getPoints() + taskInfo.getPoints());
                userInfoService.updateById(userInfo);
            }
            if (postInfo.getType().equals("7") || postInfo.getType().equals("8") || postInfo.getType().equals("8")) {
                taskRecordService.remove(Wrappers.<TaskRecord>lambdaQuery()
                        .eq(TaskRecord::getUserId, postInfo.getUserId())
                        .eq(TaskRecord::getTaskId, postInfo.getTaskId()));
            }
            return super.updateById(postInfo);
        }
        return Boolean.TRUE;
    }
}
