package com.jump.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jump.entity.ShareRecord;

/**
 * 分享记录
 *
 * @date 2024-07-06 03:47:29
 */
public interface ShareRecordMapper extends BaseMapper<ShareRecord> {

}
