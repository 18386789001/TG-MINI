
package com.jump.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jump.entity.SignRecord;

/**
 * 签到记录
 */
public interface SignRecordMapper extends BaseMapper<SignRecord> {

}
