package com.jump.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jump.entity.UmsAdmin;

public interface UmsAdminMapper extends BaseMapper<UmsAdmin> {

}
