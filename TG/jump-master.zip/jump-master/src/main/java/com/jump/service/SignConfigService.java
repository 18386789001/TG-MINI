
package com.jump.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.SignConfig;

/**
 * 签到设置
 */
public interface SignConfigService extends IService<SignConfig> {

}
