package com.jump.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;

@Data
@TableName("post_info")
@EqualsAndHashCode(callSuper = true)
public class PostInfo extends Model<PostInfo> {

    @TableId(type = IdType.ASSIGN_ID)
    private String id;
    private String userId;
    private String taskId;
    private String postTitle;
    private String postContent;
    private String imgUrl;
    @TableField(value = "`type`")
    private String type;
    private String status;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
