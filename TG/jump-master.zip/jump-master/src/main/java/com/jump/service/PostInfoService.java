package com.jump.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.PostInfo;
import com.jump.po.PostInfoPo;

public interface PostInfoService extends IService<PostInfo> {

    /**
     * 提交帖子
     * @param postInfoPo
     * @return
     */
    Boolean submit(PostInfoPo postInfoPo);
}
