package com.jump.service.impl;


import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jump.entity.GameConfig;
import com.jump.entity.GameRecord;
import com.jump.entity.UserInfo;
import com.jump.mapper.UserInfoMapper;
import com.jump.po.GameRecordPo;
import com.jump.service.GameConfigService;
import com.jump.service.GameRecordService;
import com.jump.service.GameService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class GameServiceImpl implements GameService {

    @Autowired
    private UserInfoMapper userInfoMapper;
    @Autowired
    private GameRecordService gameRecordService;
    @Autowired
    private GameConfigService gameConfigService;

    @Override
    public Boolean start(UserInfo userInfo) {
        GameConfig gameConfig = gameConfigService.getOne(Wrappers.query());
        if (userInfo.getHp() < gameConfig.getHp()) {
            return false;
        }
        return Boolean.TRUE;
    }

    @Override
    public Boolean clearance(UserInfo userInfo,GameRecordPo gameRecordPo) {
        GameConfig gameConfig = gameConfigService.getOne(Wrappers.query());
        if (userInfo.getHp() < gameConfig.getHp()) {
            return false;
        }
        GameRecord gemaRecord = gameRecordService.getOne(Wrappers.<GameRecord>lambdaQuery().eq(GameRecord::getUserId, userInfo.getId()));
        if (gemaRecord != null) {
            gemaRecord.setPoints(gemaRecord.getPoints() + gameRecordPo.getTimes());
            gameRecordService.updateById(gemaRecord);
        }else {
            gemaRecord = new GameRecord();
            gemaRecord.setUserName(userInfo.getUserName());
            gemaRecord.setCreateTime(LocalDateTime.now());
            gemaRecord.setPoints(gameRecordPo.getTimes());
            gemaRecord.setUserId(userInfo.getId());
            gemaRecord.setTimes(gameRecordPo.getTimes());
            gameRecordService.save(gemaRecord);
        }
        userInfo.setHp(userInfo.getHp() - gameConfig.getHp());
        userInfo.setPoints(userInfo.getPoints() + gameRecordPo.getTimes());
        userInfoMapper.updateById(userInfo);
        return Boolean.TRUE;
    }

    @Override
    public Boolean record(UserInfo userInfo, GameRecordPo gameRecordPo) {
        GameConfig gameConfig = gameConfigService.getOne(Wrappers.query());
        if (userInfo.getHp() < gameConfig.getHp()) {
            return false;
        }
        GameRecord gemaRecord = gameRecordService.getOne(Wrappers.<GameRecord>lambdaQuery().eq(GameRecord::getUserId, userInfo.getId()));
        if (gemaRecord != null) {
            gemaRecord.setPoints(gemaRecord.getPoints() + gameRecordPo.getTimes());
            gameRecordService.updateById(gemaRecord);
        }else {
            gemaRecord = new GameRecord();
            gemaRecord.setUserName(userInfo.getUserName());
            gemaRecord.setCreateTime(LocalDateTime.now());
            gemaRecord.setPoints(gameRecordPo.getTimes());
            gemaRecord.setUserId(userInfo.getId());
            gemaRecord.setTimes(gameRecordPo.getTimes());
            gameRecordService.save(gemaRecord);
        }
        userInfo.setHp(userInfo.getHp() - gameConfig.getHp());
        userInfo.setPoints(userInfo.getPoints() + gameRecordPo.getTimes());
        userInfoMapper.updateById(userInfo);
        return Boolean.TRUE;
    }
}
