package com.jump.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.GameRecord;
import com.jump.mapper.GameRecordMapper;
import com.jump.service.GameRecordService;
import org.springframework.stereotype.Service;

/**
 * @author :
 * @date : 2024/6/28  11:24
 */
@Service
public class GameRecordServiceImpl extends ServiceImpl<GameRecordMapper, GameRecord> implements GameRecordService {
}
