package com.jump.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jump.entity.GameRecord;

/**
 * @author :
 * @date : 2024/6/28  11:24
 */

public interface GameRecordMapper extends BaseMapper<GameRecord> {
}
