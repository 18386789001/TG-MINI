package com.jump.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jump.entity.PostInfo;

public interface PostInfoMapper extends BaseMapper<PostInfo> {
}
