package com.jump.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
@ConfigurationProperties(prefix = "twitter")
public class TwitterConfig {

    /**
     * 客户id和客户私钥
     */
    private String clientId;
    private String clientSecret;
    /**
     * 应用KYE和私钥
     */
    private String consumerKey;
    private String consumerSecret;
    /**
     * 应用的TOKEN
     */
    private String accessToken;
    private String accessTokenSecret;


}
