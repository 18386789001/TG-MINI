package com.jump.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jump.entity.WalletCategory;

/**
 * 钱包分类表
 *
 * @date 2024-07-11 21:23:27
 */
public interface WalletCategoryMapper extends BaseMapper<WalletCategory> {

}
