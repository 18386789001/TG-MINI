package com.jump.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.GameConfig;
import com.jump.service.GameConfigService;
import com.jump.mapper.GameConfigMapper;
import org.springframework.stereotype.Service;

/**
 * 
 *
 * @date 2024-07-06 21:16:02
 */
@Service
public class GameConfigServiceImpl extends ServiceImpl<GameConfigMapper, GameConfig> implements GameConfigService {

}
