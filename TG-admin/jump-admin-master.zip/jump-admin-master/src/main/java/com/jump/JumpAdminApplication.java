package com.jump;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JumpAdminApplication {

    public static void main(String[] args) {
        SpringApplication.run(JumpAdminApplication.class, args);
    }

}
