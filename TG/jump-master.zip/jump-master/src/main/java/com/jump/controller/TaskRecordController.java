package com.jump.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jump.annotation.ApiLogin;
import com.jump.constant.R;
import com.jump.entity.TaskRecord;
import com.jump.po.TaskRecordPo;
import com.jump.service.TaskRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 任务完成记录
 *
 * @date 2024-06-30 21:11:36
 */
@Slf4j
@RestController
@RequestMapping("/taskrecord")
public class TaskRecordController {

    @Autowired
    private TaskRecordService taskRecordService;

    /**
     * 任务完成记录分页列表
     *
     * @param page       分页对象
     * @param taskRecord 任务完成记录
     * @return
     */
    @GetMapping("/page")
    @ApiLogin
    public R getPage(Page page, TaskRecord taskRecord) {
        return R.ok(taskRecordService.page(page, Wrappers.query(taskRecord)));
    }


    /**
     * 添加任务记录
     *
     * @param page         分页对象
     * @param taskRecordPo 任务完成记录
     * @return
     */
    @PostMapping("/add")
    @ApiLogin
    public R add(@RequestBody TaskRecordPo taskRecordPo) {
        return R.ok(taskRecordService.add(taskRecordPo));
    }


    /**
     * 加入channel
     *
     * @param page         分页对象
     * @param taskRecordPo 任务完成记录
     * @return
     */
    @PostMapping("/joinChannel")
    @ApiLogin
    public R joinChannel(@RequestBody TaskRecordPo taskRecordPo) {
        return R.ok(taskRecordService.joinChannel(taskRecordPo));
    }


    /**
     * 加入channel
     *
     * @param page         分页对象
     * @param taskRecordPo 任务完成记录
     * @return
     */
    @PostMapping("/followX")
    @ApiLogin
    public R followX(@RequestBody TaskRecordPo taskRecordPo) {
        return R.ok(taskRecordService.followX(taskRecordPo));
    }

    /**
     * 确认完成任务
     *
     * @param page         分页对象
     * @param taskRecordPo 任务完成记录
     * @return
     */
    @PostMapping("/confirmCompletion")
    @ApiLogin
    public R confirmCompletion(@RequestBody TaskRecordPo taskRecordPo) {
        return R.ok(taskRecordService.confirmCompletion(taskRecordPo));
    }


}
