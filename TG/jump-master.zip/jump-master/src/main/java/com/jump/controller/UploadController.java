package com.jump.controller;

import cn.hutool.core.util.IdUtil;
import com.jump.constant.R;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

@Slf4j
@RestController
@RequestMapping
public class UploadController {

    @Value("${images.path}")
    private String path;
    @Value("${images.domain}")
    private String domain;

    @PostMapping("/upload")
    public R handleFileUpload(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return R.failed("The file is empty");
        }
        try {
            String filename =generateFileName(file.getOriginalFilename()) ;
            Path filePath = Paths.get(path + filename);
            Files.copy(file.getInputStream(), filePath);
            String imgUrl = domain + "images" + filename;
            return R.ok(imgUrl);
        } catch (IOException e) {
            e.printStackTrace();
            return R.failed("File upload failed");
        }
    }

    private String generateFileName(String originalFilename) {
        // 这里可以添加更复杂的逻辑来生成新的文件名
        int dotIndex = originalFilename.lastIndexOf('.');
        return IdUtil.createSnowflake(1,1).nextIdStr()
                + originalFilename.substring(dotIndex);
    }
}
