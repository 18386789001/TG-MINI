package com.jump.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.ShareConfig;

/**
 * 分享配置
 *
 * @date 2024-06-30 21:11:22
 */
public interface ShareConfigService extends IService<ShareConfig> {

}
