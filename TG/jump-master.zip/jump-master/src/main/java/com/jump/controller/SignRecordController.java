
package com.jump.controller;

import com.jump.annotation.ApiLogin;
import com.jump.constant.R;
import com.jump.service.SignRecordService;
import com.jump.util.ThirdSessionHolder;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 签到记录
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/signrecord")
public class SignRecordController {

    private final SignRecordService signRecordService;

    /**
     * 签到记录查询
     * @return R
     */
    @GetMapping("/user")
	@ApiLogin
    public R getById() {
        return R.ok(signRecordService.getSignRecord(ThirdSessionHolder.getUserId()));
    }

	/**
	 * 用户签到
	 * @return R
	 */
	@PostMapping("/user")
	@ApiLogin
	public R userSign(){
		return R.ok(signRecordService.userSign(ThirdSessionHolder.getUserId()));
	}
}
