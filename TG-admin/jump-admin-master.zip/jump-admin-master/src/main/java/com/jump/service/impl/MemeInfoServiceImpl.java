package com.jump.service.impl;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.*;
import com.jump.mapper.MemeInfoMapper;
import com.jump.po.MemeInfoPo;
import com.jump.po.PostInfoPo;
import com.jump.service.MemeInfoService;
import com.jump.service.TaskInfoService;
import com.jump.service.TaskRecordService;
import com.jump.service.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MemeInfoServiceImpl extends ServiceImpl<MemeInfoMapper, MemeInfo> implements MemeInfoService {

    @Autowired
    private TaskRecordService taskRecordService;
    @Autowired
    private UserInfoService userInfoService;
    @Autowired
    private TaskInfoService taskInfoService;

    @Override
    public Boolean verify(MemeInfoPo memeInfoPo) {
        MemeInfo memeInfo = baseMapper.selectById(memeInfoPo.getId());
        memeInfo.setStatus(memeInfoPo.getStatus());
        if (memeInfoPo.getStatus().equals("2")) {
            TaskRecord taskRecord = taskRecordService.getOne(Wrappers.<TaskRecord>lambdaQuery()
                    .eq(TaskRecord::getUserId, memeInfo.getUserId())
                    .eq(TaskRecord::getTaskId, memeInfo.getTaskId()));
            taskRecord.setStatus("2");
            taskRecordService.updateById(taskRecord);
            TaskInfo taskInfo = taskInfoService.getById(taskRecord.getTaskId());
            UserInfo userInfo = userInfoService.getById(memeInfo.getUserId());
            userInfo.setPoints(userInfo.getPoints() + taskInfo.getPoints());
            userInfoService.updateById(userInfo);
        }
        return super.updateById(memeInfo);
    }
}
