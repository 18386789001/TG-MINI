package com.jump.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.WalletCategory;

/**
 * 钱包分类表
 *
 * @date 2024-07-11 21:23:27
 */
public interface WalletCategoryService extends IService<WalletCategory> {

}
