package com.jump.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.ShareConfig;
import com.jump.mapper.ShareConfigMapper;
import com.jump.service.ShareConfigService;
import org.springframework.stereotype.Service;

/**
 * 分享配置
 *
 * @date 2024-06-30 21:11:22
 */
@Service
public class ShareConfigServiceImpl extends ServiceImpl<ShareConfigMapper, ShareConfig> implements ShareConfigService {

}
