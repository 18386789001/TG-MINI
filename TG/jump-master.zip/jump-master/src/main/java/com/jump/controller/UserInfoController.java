package com.jump.controller;


import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jump.annotation.ApiLogin;
import com.jump.constant.R;
import com.jump.entity.UserInfo;
import com.jump.entity.WalletInfo;
import com.jump.po.LoginDTO;
import com.jump.po.ShareInfoVo;
import com.jump.po.UserInfoLoginDTO;
import com.jump.service.UserInfoService;
import com.jump.service.WalletInfoService;
import com.jump.util.ThirdSession;
import com.jump.util.ThirdSessionHolder;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.catalina.User;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import org.telegram.telegrambots.meta.TelegramBotsApi;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;


@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/userinfo")
public class UserInfoController {

    private final UserInfoService userInfoService;
    private final WalletInfoService walletInfoService;


    /**
     * 查询商城用户
     *
     * @return R
     */
    @GetMapping
    @ApiLogin
    public R getById() {
        UserInfo userInfo = new UserInfo();
        userInfo.setId(ThirdSessionHolder.getUserId());
        userInfo = userInfoService.getById(userInfo.getId());
        List<WalletInfo> walletInfoList = walletInfoService.list(Wrappers.<WalletInfo>lambdaQuery()
                .eq(WalletInfo::getUserId, ThirdSessionHolder.getUserId()));
        if (!CollectionUtils.isEmpty(walletInfoList)) {
            List<String> walletUrlList = walletInfoList.stream().map(WalletInfo::getWalletUrl).collect(Collectors.toList());
            userInfo.setWalletUrlList(walletUrlList);
        }
        return R.ok(userInfo);
    }

    /**
     * 账号登录
     *
     * @param userInfoLoginDTO
     * @return
     */
    @GetMapping("/login")
    public R login(HttpServletRequest request, @ModelAttribute UserInfoLoginDTO userInfoLoginDTO) {
        log.info(JSONUtil.toJsonStr(userInfoLoginDTO));
        //登录
        UserInfo userInfo = userInfoService.login(request, userInfoLoginDTO);
        return R.ok(userInfo);
    }


    /**
     * 账号登录
     *
     * @param loginDTO
     * @return
     */
    @PostMapping("/telegram/login")
    public R telegramLogin(HttpServletRequest request, @RequestBody LoginDTO loginDTO) {
        log.info(JSONUtil.toJsonStr(loginDTO));
        //登录
        UserInfo userInfo = userInfoService.login1(request, loginDTO);
        return R.ok(userInfo);
    }


    /**
     * 获取分享信息
     *
     * @param
     * @return
     */
    @PostMapping("/getShareInfo")
    @ApiLogin
    public R getShareInfo() {
        String userId = ThirdSessionHolder.getUserId();
        ShareInfoVo shareInfoVo = userInfoService.getShareInfo(userId);
        return R.ok(shareInfoVo);
    }


}
