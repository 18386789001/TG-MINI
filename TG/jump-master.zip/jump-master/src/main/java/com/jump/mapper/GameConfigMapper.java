package com.jump.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jump.entity.GameConfig;

/**
 * 
 *
 * @date 2024-07-06 21:16:02
 */
public interface GameConfigMapper extends BaseMapper<GameConfig> {

}
