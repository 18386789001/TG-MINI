package com.jump.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;

/**
 * 任务
 *
 * @date 2024-06-30 21:10:46
 */
@Data
@TableName("task_info")
@EqualsAndHashCode(callSuper = true)
public class TaskInfo extends Model<TaskInfo> {
    private static final long serialVersionUID = 1L;

    /**
     * PK
     */
    @TableId(type = IdType.ASSIGN_ID)
    private String id;

    private String logUrl;

    /**
     * 描述
     */
    @TableField(value = "`describe`")
    private String describe;
    /**
     * 任务金币
     */
    private Integer points;
    /**
     * 类别（1、社会任务；2、每日任务）
     */
    private String categoryType;
    /**
     * 类型
     */
    @TableField(value = "`type`")
    private String type;

    /**
     * 任务链接地址
     */
    private String url;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 修改时间
     */
    private LocalDateTime updateTime;

    @TableField(exist = false)
    private String status;

}
