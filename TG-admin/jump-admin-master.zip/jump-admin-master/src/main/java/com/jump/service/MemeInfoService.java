package com.jump.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.MemeInfo;
import com.jump.po.MemeInfoPo;

public interface MemeInfoService extends IService<MemeInfo> {


    Boolean verify(MemeInfoPo memeInfoPo);
}
