package com.jump.service.impl;

import com.jump.service.TwitterService;
import org.springframework.social.twitter.api.Twitter;
import org.springframework.social.twitter.api.impl.TwitterTemplate;
import org.springframework.stereotype.Service;

@Service
public class TwitterServiceImpl implements TwitterService {

//    private final Twitter twitter;
//
//    public TwitterServiceImpl(TwitterTemplate twitterTemplate) {
//        this.twitter = twitterTemplate;
//    }
}
