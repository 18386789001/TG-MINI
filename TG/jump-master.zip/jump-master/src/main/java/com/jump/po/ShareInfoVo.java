package com.jump.po;

import lombok.Data;

@Data
public class ShareInfoVo {

    private Integer peopleNumber = 0;
    private Integer points = 0;

}
