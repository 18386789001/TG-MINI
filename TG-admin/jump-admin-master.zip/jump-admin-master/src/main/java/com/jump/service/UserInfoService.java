
package com.jump.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.UserInfo;
import org.springframework.security.core.userdetails.UserDetails;

/**
 * 签到设置
 */
public interface UserInfoService extends IService<UserInfo> {

}
