package com.jump.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jump.entity.TaskInfo;

/**
 * 任务
 *
 * @date 2024-06-30 21:10:46
 */
public interface TaskInfoMapper extends BaseMapper<TaskInfo> {

}
