package com.jump.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jump.entity.TaskInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 任务
 *
 * @date 2024-06-30 21:10:46
 */
public interface TaskInfoMapper extends BaseMapper<TaskInfo> {

    List<TaskInfo> selectPage1( @Param("userId") String userId);
}
