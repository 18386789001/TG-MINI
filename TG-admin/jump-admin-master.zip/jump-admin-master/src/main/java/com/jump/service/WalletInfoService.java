package com.jump.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.WalletInfo;

/**
 * 钱包
 *
 * @date 2024-07-03 22:07:39
 */
public interface WalletInfoService extends IService<WalletInfo> {

}
