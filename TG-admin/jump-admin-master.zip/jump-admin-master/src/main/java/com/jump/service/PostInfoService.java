package com.jump.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.PostInfo;
import com.jump.po.PostInfoPo;

public interface PostInfoService extends IService<PostInfo> {

     Boolean verify(PostInfoPo postInfoPo);
}
