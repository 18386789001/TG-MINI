package com.jump.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.TaskInfo;
import com.jump.entity.TaskRecord;
import com.jump.mapper.TaskInfoMapper;
import com.jump.service.TaskInfoService;
import com.jump.service.TaskRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * 任务
 *
 * @date 2024-06-30 21:10:46
 */
@Service
public class TaskInfoServiceImpl extends ServiceImpl<TaskInfoMapper, TaskInfo> implements TaskInfoService {

    @Autowired
    private TaskRecordService taskRecordService;

    @Override
    public IPage<TaskInfo> page1(Page page, QueryWrapper<TaskInfo> query) {
        IPage<TaskInfo> taskInfoIPage = baseMapper.selectPage(page, query);
        taskInfoIPage.getRecords().forEach(taskInfo -> {
            TaskRecord taskRecord = taskRecordService.getOne(Wrappers.<TaskRecord>lambdaQuery()
                    .eq(TaskRecord::getTaskId, taskInfo.getId()));
            if (taskRecord != null) {
                taskInfo.setStatus(taskRecord.getStatus());
            }
        });
        return taskInfoIPage;
    }


    @Override
    public IPage<TaskInfo> getCompletedPage(Page page, QueryWrapper<TaskInfo> query) {
        IPage<TaskRecord> recordIPage = taskRecordService.page(page, Wrappers.<TaskRecord>lambdaQuery()
                .eq(TaskRecord::getStatus, "2"));
        List<TaskInfo> taskInfoList = new ArrayList<>();
        recordIPage.getRecords().forEach(taskRecord -> {
            TaskInfo taskInfo = baseMapper.selectById(taskRecord.getTaskId());
            taskInfo.setStatus("2");
            taskInfoList.add(taskInfo);
        });
        IPage<TaskInfo> taskInfoIPage = new Page<>();
        taskInfoIPage.setRecords(taskInfoList);
        taskInfoIPage.setCurrent(recordIPage.getCurrent());
        taskInfoIPage.setSize(recordIPage.getSize());
        taskInfoIPage.setTotal(recordIPage.getTotal());
        return taskInfoIPage;
    }
}
