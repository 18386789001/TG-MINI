package com.jump.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.MemeInfo;
import com.jump.entity.TaskRecord;
import com.jump.mapper.MemeInfoMapper;
import com.jump.po.MemeInfoPo;
import com.jump.service.MemeInfoService;
import com.jump.service.TaskRecordService;
import com.jump.util.ThirdSessionHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class MemeInfoServiceImpl extends ServiceImpl<MemeInfoMapper, MemeInfo> implements MemeInfoService {

    @Autowired
    private TaskRecordService taskRecordService;


    @Override
    @Transactional
    public Boolean submit(MemeInfoPo memeInfoPo) {
        MemeInfo memeInfo = new MemeInfo();
        memeInfo.setPostContent(memeInfoPo.getPostContent());
        memeInfo.setCreateTime(LocalDateTime.now());
        memeInfo.setUpdateTime(LocalDateTime.now());
        memeInfo.setUserId(ThirdSessionHolder.getUserId());
        memeInfo.setTaskId(memeInfoPo.getTaskId());
        Boolean boo = super.save(memeInfo);
        if (boo) {
            TaskRecord taskRecord = new TaskRecord();
            taskRecord.setCompleteTime(LocalDateTime.now());
            taskRecord.setCreateTime(LocalDateTime.now());
            taskRecord.setStatus("1");
            taskRecord.setTaskId(memeInfoPo.getTaskId());
            taskRecord.setUserId(ThirdSessionHolder.getUserId());
            taskRecordService.save(taskRecord);
        }

        return boo;
    }
}
