
package com.jump.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 加上此注解，接口必须登录带session才能访问

 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface ApiLogin {

	/**
	 * 必须登录才能访问，默认true
	 * @return
	 */
	boolean mustLogin() default true;

}
