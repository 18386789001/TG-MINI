package com.jump.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

/**
 * 钱包分类表
 *
 * @date 2024-07-11 21:23:27
 */
@Data
@TableName("wallet_category")
@EqualsAndHashCode(callSuper = true)
public class WalletCategory extends Model<WalletCategory> {
    private static final long serialVersionUID=1L;

    /**
     * PK
     */
    @TableId(type = IdType.AUTO)
    @NotNull(message = "PK不能为空")
    private String id;
    /**
     * 图标
     */
    @NotNull(message = "图标不能为空")
    private String logUrl;
    /**
     * 名称
     */
    @NotNull(message = "名称不能为空")
    private String name;

}
