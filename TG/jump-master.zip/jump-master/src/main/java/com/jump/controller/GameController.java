package com.jump.controller;


import com.jump.annotation.ApiLogin;
import com.jump.constant.R;
import com.jump.entity.UserInfo;
import com.jump.po.GameRecordPo;
import com.jump.service.GameService;
import com.jump.service.UserInfoService;
import com.jump.util.ThirdSessionHolder;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/game")
public class GameController {


    private final GameService gameService;
    private final UserInfoService userInfoService;

    /**
     * 开始游戏
     */
    @PostMapping("/start")
    @ApiLogin
    public R<Boolean> start() {
        UserInfo userInfo = verification();
//        if (userInfo == null) {
//            return R.failed(10001, "token失效");
//        }
        return R.ok(gameService.start(userInfo));
    }


    /**
     * 游戏通关
     */
    @PostMapping("/clearance")
    @ApiLogin
    public R<Boolean> clearance(@RequestBody GameRecordPo gameRecordPo) {
        UserInfo userInfo = verification();
//        if (userInfo == null) {
//            return R.failed(10001, "token失效");
//        }
        return R.ok(gameService.clearance(userInfo,gameRecordPo));
    }


    /**
     * 游戏通关
     */
    @PostMapping("/record")
    @ApiLogin
    public R<Boolean> record(@RequestBody GameRecordPo gameRecordPo) {
        UserInfo userInfo = verification();
        if (userInfo == null) {
            return R.failed(10001, "token失效");
        }
        if (gameRecordPo.getTimes() < 1) {
            return R.failed(50001, "失败");
        }
        return R.ok(gameService.record(userInfo, gameRecordPo));
    }


    /**
     * 登录验证（临时）
     */
    private UserInfo verification() {
        UserInfo userInfo = userInfoService.getById(ThirdSessionHolder.getUserId());
        return userInfo;
    }

}
