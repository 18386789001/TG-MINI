
package com.jump.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.SignConfig;
import com.jump.entity.SignRecord;

/**
 * 签到记录
 *

 * @date 2021-01-13 15:29:30
 */
public interface SignRecordService extends IService<SignRecord> {

	/**
	 * 查询签到信息
	 * @param userId
	 * @return
	 */
	SignRecord getSignRecord(String userId);

	/**
	 * 用户签到
	 */
	SignConfig userSign(String userId);
}
