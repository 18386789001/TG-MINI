package com.jump.config;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.jump.service.TaskRecordService;
import org.springframework.data.redis.core.RedisTemplate;
import org.telegram.telegrambots.bots.DefaultBotOptions;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.groupadministration.GetChatMember;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Chat;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.User;
import org.telegram.telegrambots.meta.api.objects.chatmember.ChatMember;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.util.*;

public class MyBot extends TelegramLongPollingBot {


    private final TelegramConfigProperties telegramConfigProperties;
    private final RedisTemplate redisTemplate;
    private final TaskRecordService taskRecordService;

    public MyBot(DefaultBotOptions botOptions,
                 RedisTemplate redisTemplate,
                 TelegramConfigProperties telegramConfigProperties, TaskRecordService taskRecordService) {
        super(botOptions);
        this.redisTemplate = redisTemplate;
        this.telegramConfigProperties = telegramConfigProperties;
        this.taskRecordService = taskRecordService;
    }


    @Override
    public String getBotUsername() {
        return this.telegramConfigProperties.getBotName();
    }

    @Override
    public String getBotToken() {
        return this.telegramConfigProperties.getToken();
    }

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage()) {
            Message message = update.getMessage();
            if (message.getNewChatMembers() != null && !message.getNewChatMembers().isEmpty()) {
                List<User> newMembers = message.getNewChatMembers();
                for (User member : newMembers) {
                    taskRecordService.handMessage(member.getId());
                    member.getId();
                }
            }
            if (update.getMessage().getText().contains("/start")) {

                String lastName = update.getMessage().getChat().getLastName();
                String firstName = update.getMessage().getChat().getFirstName();
                String userName = "";
                if (!StrUtil.isEmpty(lastName)) {
                    userName = lastName;
                }
                if (!StrUtil.isEmpty(firstName)) {
                    userName = userName + firstName;
                }
                InlineKeyboardButton button1 = InlineKeyboardButton.builder().url("https://t.me/JumpAndSay_bot/Jump").text("Launch bot").callbackData("opt").build();
                List<InlineKeyboardButton> list1 = new ArrayList<>();
                list1.add(button1);
                List<List<InlineKeyboardButton>> rowList = new ArrayList<>();
                Collections.addAll(rowList, list1);
                InlineKeyboardMarkup inlineKeyboardMarkup = InlineKeyboardMarkup.builder().keyboard(rowList).build();
                SendMessage sendMessage = SendMessage.builder()
                        .text("Hey @"+userName+"! \n" +
                                "\n" +
                                "Welcome to the DAWG pack \uD83D\uDC36 Now is your chance to grab your rewards: \n" +
                                "\n" +
                                "\uD83D\uDCB0 Play DAWG Jump: Jump as far as you can. Rank and be the leader of the dawgpack. \n" +
                                "\n" +
                                "\uD83C\uDFC6 Daily Quests: Complete quests and win points. \n" +
                                "\n" +
                                "⏰ Checkin: Login daily and earn streak multipliers. \n" +
                                "\n" +
                                "\uD83D\uDC36 Invite your DAWGs: Bring your friends into the game and win a % of all their points!")
                        .chatId(update.getMessage().getChatId().toString())
                        .replyMarkup(inlineKeyboardMarkup)
                        .build();
                try {
                    execute(sendMessage);

                    Map<String, String> map = new HashMap<>();
                    map.put("chatId", update.getMessage().getChatId().toString());
                    map.put("userName", userName);
                    String text = update.getMessage().getText();
                    if (!text.contains("login")) {
                        String[] cont = text.split(" ");
                        if (cont.length > 1) {
                            map.put("sharerChatId", cont[1]);
                        }
                    }
//                                        map.put("photoUrl", update.getMessage().getChat().getPhoto());
                    redisTemplate.opsForValue().set("user:" + update.getMessage().getChatId(), JSONUtil.toJsonStr(map));
                } catch (TelegramApiException e) {
                    e.printStackTrace();
                }
            }
        }

    }

    private void sendWelcomeMessage(String chatId, String text) {
        SendMessage message = new SendMessage();
        message.setChatId(chatId);
        message.setText(text);
        try {
            execute(message);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }
}
