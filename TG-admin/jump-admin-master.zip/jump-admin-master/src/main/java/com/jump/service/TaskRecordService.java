package com.jump.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.TaskRecord;

/**
 * 任务完成记录
 *
 * @date 2024-06-30 21:11:36
 */
public interface TaskRecordService extends IService<TaskRecord> {

}
