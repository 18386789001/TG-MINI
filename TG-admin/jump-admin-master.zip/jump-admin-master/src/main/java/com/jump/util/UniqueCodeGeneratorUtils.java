package com.jump.util;

import java.util.concurrent.atomic.AtomicLong;

public class UniqueCodeGeneratorUtils {


    // 假设你有一个原子长整型来生成唯一的ID
    private static final AtomicLong counter = new AtomicLong(System.currentTimeMillis());

    // 假设我们有一个固定的字符集来生成编码
    private static final String CHARACTERS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";

    // 生成一个长度为6的编码
    public static String generateSixDigitCode() {
        // 获取一个唯一的ID（这里只是一个简化的示例，不是真正的全局唯一）
        long id = counter.incrementAndGet();

        // 将ID转换为Base62编码的字符串，但这里我们只取前6个字符作为近似值
        // 注意：这不会真正确保6位字符串的唯一性！
        StringBuilder sb = new StringBuilder();
        while (sb.length() < 6) {
            // 使用ID的当前位（0-61）作为索引来获取字符
            int index = (int) (id % CHARACTERS.length());
            sb.append(CHARACTERS.charAt(index));
            // 无符号右移，相当于丢弃最低位的几个比特
            id >>>= 6;
            // 如果ID已经为0，退出循环（但这里我们假设ID总是足够长以生成至少6个字符）
            if (id == 0) break;
        }

        // 如果生成的字符串长度小于6（这不应该发生，但作为一种防御性编程措施）
        // 你可以在这里添加一些逻辑来填充剩余的字符，例如使用固定的字符或重新生成ID
        while (sb.length() < 6) {
            sb.append(CHARACTERS.charAt(0)); // 使用字符集中的第一个字符作为填充
        }

        // 返回生成的6位编码
        return sb.toString();
    }

    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            System.out.println(generateSixDigitCode());
        }
    }
}
