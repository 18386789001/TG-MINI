package com.jump.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jump.entity.MemeInfo;

public interface MemeInfoMapper extends BaseMapper<MemeInfo> {
}
