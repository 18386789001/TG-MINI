package com.jump.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;

/**
 * 分享配置
 *
 * @date 2024-06-30 21:11:22
 */
@Data
@TableName("share_config")
@EqualsAndHashCode(callSuper = true)
public class ShareConfig extends Model<ShareConfig> {
    private static final long serialVersionUID=1L;

    /**
     * PK
     */
    @TableId(type = IdType.ASSIGN_ID)
    private String id;
    /**
     * 新注册用户赠送积分
     */
    private Integer points;
    /**
     * 分享人获得积分比例
     */
    private BigDecimal scale;

}
