package com.jump.service.impl;

import com.jump.service.TelegramBotService;

public class TelegramBotServiceImpl implements TelegramBotService {
}
