package com.jump.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;


/**
 * 钱包
 *
 * @date 2024-07-03 22:07:39
 */
@Data
@TableName("wallet_info")
@EqualsAndHashCode(callSuper = true)
public class WalletInfo extends Model<WalletInfo> {
    private static final long serialVersionUID = 1L;

    /**
     * Pk
     */
    @TableId(type = IdType.ASSIGN_ID)
    private String id;

    /**
     *
     */
    private String walletCategoryId;

    /**
     * 用户id
     */
    private String userId;
    /**
     * 钱包地址
     */
    private String walletUrl;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 最后更新（签到）时间
     */
    private LocalDateTime updateTime;

}
