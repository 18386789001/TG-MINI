package com.jump.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.MemeInfo;
import com.jump.entity.PostInfo;
import com.jump.po.MemeInfoPo;
import com.jump.po.PostInfoPo;

public interface MemeInfoService extends IService<MemeInfo> {

    /**
     * 提交
     *
     * @param memeInfoPo
     * @return
     */
    Boolean submit(MemeInfoPo memeInfoPo);
}
