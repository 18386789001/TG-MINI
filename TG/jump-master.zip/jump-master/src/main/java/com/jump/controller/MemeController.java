package com.jump.controller;

import com.jump.annotation.ApiLogin;
import com.jump.constant.R;
import com.jump.po.MemeInfoPo;
import com.jump.po.PostInfoPo;
import com.jump.service.MemeInfoService;
import com.jump.service.PostInfoService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/meme")
public class MemeController {

    @Autowired
    private MemeInfoService memeInfoService;

    /**
     * 开始游戏
     */
    @PostMapping("/submit")
    @ApiLogin
    public R<Boolean> submit(@RequestBody MemeInfoPo memeInfoPo) {
        return R.ok(memeInfoService.submit(memeInfoPo));
    }


}
