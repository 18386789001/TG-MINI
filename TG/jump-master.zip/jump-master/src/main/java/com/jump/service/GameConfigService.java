package com.jump.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.GameConfig;

/**
 * 
 *
 * @date 2024-07-06 21:16:02
 */
public interface GameConfigService extends IService<GameConfig> {

}
