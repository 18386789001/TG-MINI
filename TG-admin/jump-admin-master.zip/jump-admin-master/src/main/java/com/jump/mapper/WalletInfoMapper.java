package com.jump.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jump.entity.WalletInfo;

/**
 * 钱包
 *
 * @date 2024-07-03 22:07:39
 */
public interface WalletInfoMapper extends BaseMapper<WalletInfo> {

}
