package com.jump.service.impl;

import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jump.entity.TaskInfo;
import com.jump.service.TaskInfoService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class TaskInfoServiceImplTest {

    @Autowired
    private TaskInfoService taskInfoService;


    @Test
    public void page2() {
        System.out.println(JSONUtil.toJsonStr(taskInfoService.page2(Wrappers.query(new TaskInfo()))));
    }
}