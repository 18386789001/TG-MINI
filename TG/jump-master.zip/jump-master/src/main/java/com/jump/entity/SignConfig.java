
package com.jump.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;
import javax.validation.constraints.NotNull;


/**
 * 签到设置

 */
@Data
@TableName("sign_config")
@EqualsAndHashCode(callSuper = true)
public class SignConfig extends Model<SignConfig> {
    private static final long serialVersionUID=1L;

    /**
     * PK
     */
    @TableId(type = IdType.ASSIGN_ID)
    @NotNull(message = "PK不能为空")
    private String id;
    /**
     * 排序字段
     */
    @NotNull(message = "排序字段不能为空")
    private Integer sort;
    /**
     * 名字
     */
    @NotNull(message = "名字不能为空")
    private String name;
    /**
     * 积分数
     */
    @NotNull(message = "积分数不能为空")
    private Integer posts;

}
