package com.jump.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.SignConfig;
import com.jump.entity.SignRecord;
import com.jump.entity.TaskInfo;
import com.jump.entity.TaskRecord;
import com.jump.mapper.TaskInfoMapper;
import com.jump.service.SignConfigService;
import com.jump.service.SignRecordService;
import com.jump.service.TaskInfoService;
import com.jump.service.TaskRecordService;
import com.jump.util.ThirdSessionHolder;
import io.undertow.Undertow;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * 任务
 *
 * @date 2024-06-30 21:10:46
 */
@Service
public class TaskInfoServiceImpl extends ServiceImpl<TaskInfoMapper, TaskInfo> implements TaskInfoService {

    @Autowired
    private TaskRecordService taskRecordService;
    @Autowired
    private SignRecordService signRecordService;
    @Autowired
    private SignConfigService signConfigService;

    @Override
    public IPage<TaskInfo> page1(Page page, QueryWrapper<TaskInfo> query) {
        String userId = ThirdSessionHolder.getUserId();
        IPage<TaskInfo> taskInfoIPage = baseMapper.selectPage(page, query);
        List<TaskInfo> taskInfoList = new ArrayList<>();
        taskInfoIPage.getRecords().forEach(taskInfo -> {
            TaskRecord taskRecord = taskRecordService.getOne(Wrappers.<TaskRecord>lambdaQuery()
                    .eq(TaskRecord::getTaskId, taskInfo.getId())
                    .eq(TaskRecord::getUserId, userId));
            if (taskRecord == null) {
                taskInfo.setStatus("0");
                taskInfoList.add(taskInfo);
            } else {
                if (!taskRecord.getStatus().equals("2")) {
                    taskInfo.setStatus(taskRecord.getStatus());
                    taskInfoList.add(taskInfo);
                }
            }
            if (taskInfo.getType().equals("4")) {
                SignRecord signRecord = signRecordService.getOne(Wrappers.<SignRecord>query().lambda()
                        .eq(SignRecord::getUserId, userId));
                int size = 0;
                if (signRecord != null) {

                    if (signRecord.getUpdateTime() != null
                            && signRecord.getUpdateTime().toLocalDate().equals(LocalDate.now())) {
                        size = signRecord.getContinuDays();
                    }
                }

                List<SignConfig> signConfigs = signConfigService.list(Wrappers.<SignConfig>lambdaQuery()
                        .orderByAsc(SignConfig::getSort));
                if (size > signConfigs.size()) {
                    taskInfo.setPoints(0);
                } else {
                    taskInfo.setPoints(signConfigs.get(size).getPosts());
                }
            }
        });
        taskInfoIPage.setRecords(taskInfoList);
        return taskInfoIPage;
    }


    @Override
    public IPage<TaskInfo> getCompletedPage(Page page, QueryWrapper<TaskInfo> query) {
        IPage<TaskRecord> recordIPage = taskRecordService.page(page, Wrappers.<TaskRecord>lambdaQuery()
                .eq(TaskRecord::getUserId, ThirdSessionHolder.getUserId())
                .eq(TaskRecord::getStatus, "2"));
        List<TaskInfo> taskInfoList = new ArrayList<>();
        recordIPage.getRecords().forEach(taskRecord -> {
            TaskInfo taskInfo = baseMapper.selectById(taskRecord.getTaskId());
            taskInfo.setStatus("2");
            taskInfoList.add(taskInfo);
        });
        IPage<TaskInfo> taskInfoIPage = new Page<>();
        taskInfoIPage.setRecords(taskInfoList);
        taskInfoIPage.setCurrent(recordIPage.getCurrent());
        taskInfoIPage.setSize(recordIPage.getSize());
        taskInfoIPage.setTotal(recordIPage.getTotal());
        return taskInfoIPage;
    }


    @Override
    public List<TaskInfo> page2(QueryWrapper<TaskInfo> query) {
        String userId = ThirdSessionHolder.getUserId();
        List<TaskInfo> taskInfoIPage = baseMapper.selectPage1(userId);
        List<TaskInfo> taskInfoList = new ArrayList<>();
        SignRecord signRecord = signRecordService.getOne(Wrappers.<SignRecord>query().lambda()
                .eq(SignRecord::getUserId, userId));
        for (TaskInfo taskInfo : taskInfoIPage) {
            if (taskInfo.getType().equals("4")) {
                if (signRecord.getUpdateTime() != null
                        && signRecord.getUpdateTime().toLocalDate().equals(LocalDate.now())) {
                    continue;
                }
                int size = 0;
                if (signRecord != null) {
                    size = signRecord.getContinuDays();
                }
                List<SignConfig> signConfigs = signConfigService.list(Wrappers.<SignConfig>lambdaQuery()
                        .orderByAsc(SignConfig::getSort));
                taskInfo.setPoints(signConfigs.get(size).getPosts());
            }
            taskInfoList.add(taskInfo);
            if (taskInfoList.size() == 3) {
                break;
            }
        }


        return taskInfoList;
    }
}
