package com.jump.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jump.constant.R;
import com.jump.entity.MemeInfo;
import com.jump.entity.PostInfo;
import com.jump.po.MemeInfoPo;
import com.jump.po.PostInfoPo;
import com.jump.service.MemeInfoService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/meme")
public class MemeController {

    @Autowired
    private MemeInfoService memeInfoService;

    @GetMapping("/page")
    public R page(Page page, MemeInfo memeInfo) {
        return R.ok(memeInfoService.page(page, Wrappers.<MemeInfo>lambdaQuery().eq(MemeInfo::getStatus, "0")));
    }

    @PostMapping("/verify")
    public R verify(@RequestBody MemeInfoPo memeInfoPo) {
        return R.ok(memeInfoService.verify(memeInfoPo));
    }


}
