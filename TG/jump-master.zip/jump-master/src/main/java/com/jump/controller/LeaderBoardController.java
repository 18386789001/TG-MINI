package com.jump.controller;


import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jump.annotation.ApiLogin;
import com.jump.constant.R;
import com.jump.entity.GameRecord;
import com.jump.entity.UserInfo;
import com.jump.service.GameRecordService;
import com.jump.service.UserInfoService;
import com.jump.util.ThirdSessionHolder;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import twitter4j.User;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/leaderboard")
public class LeaderBoardController {

    private final GameRecordService gameRecordService;
    private final UserInfoService userInfoService;

    /**
     * 获取排行榜
     *
     * @return
     */
    @GetMapping("/list")
    @ApiLogin
    public R getPage() {
        return R.ok(gameRecordService.list(Wrappers.<GameRecord>lambdaQuery()
                .orderByDesc(GameRecord::getPoints).last("limit 100")));
    }

    /**
     * 获取排行榜
     *
     * @return
     */
    @GetMapping("/userList")
    @ApiLogin
    public R getUserLeaderBoardPage() {
        List<UserInfo> userInfoList = userInfoService.list(Wrappers.<UserInfo>lambdaQuery()
                .orderByDesc(UserInfo::getPoints).last("limit 100"));
        List<GameRecord> gameRecordList = new ArrayList<>();
        userInfoList.forEach(userInfo -> {
            GameRecord gameRecord = new GameRecord();
            gameRecord.setUserName(userInfo.getUserName());
            gameRecord.setPoints(userInfo.getPoints());
            gameRecordList.add(gameRecord);
        });
        return R.ok(gameRecordList);
    }


    /**
     * 获取游戏积分
     *
     * @return
     */
    @GetMapping("/getGamePoints")
    @ApiLogin
    public R getGamePoints() {
        GameRecord gameRecord = gameRecordService.getOne(Wrappers.<GameRecord>lambdaQuery().eq(GameRecord::getUserId, ThirdSessionHolder.getUserId()));
        if (gameRecord == null) {
            gameRecord = new GameRecord();
            gameRecord.setPoints(0);
        }
        return R.ok(gameRecord);
    }
}
