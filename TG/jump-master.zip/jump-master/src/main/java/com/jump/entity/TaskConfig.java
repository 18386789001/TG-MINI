package com.jump.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

/**
 * 任务配置
 *
 * @date 2024-07-04 23:05:49
 */
@Data
@TableName("task_config")
@EqualsAndHashCode(callSuper = true)
public class TaskConfig extends Model<TaskConfig> {
    private static final long serialVersionUID=1L;

    /**
     * 
     */
    @TableId(type = IdType.ASSIGN_ID)
    @NotNull(message = "不能为空")
    private String id;
    /**
     * 有效期
     */
    @NotNull(message = "有效期不能为空")
    private Long effectiveTime;

}
