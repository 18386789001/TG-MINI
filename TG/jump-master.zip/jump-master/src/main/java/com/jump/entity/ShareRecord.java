package com.jump.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;

/**
 * 分享记录
 *
 * @date 2024-07-06 03:47:29
 */
@Data
@TableName("share_record")
@EqualsAndHashCode(callSuper = true)
public class ShareRecord extends Model<ShareRecord> {
    private static final long serialVersionUID = 1L;

    /**
     *
     */
    @TableId(type = IdType.ASSIGN_ID)
    private String id;
    /**
     *
     */
    private String userId;
    /**
     *
     */
    private String shareUserId;
    /**
     *
     */
    private Integer points;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

}
