
package com.jump.service.impl;

import com.baomidou.mybatisplus.core.metadata.OrderItem;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.SignConfig;
import com.jump.entity.SignRecord;
import com.jump.entity.TaskRecord;
import com.jump.entity.UserInfo;
import com.jump.mapper.SignConfigMapper;
import com.jump.mapper.SignRecordMapper;
import com.jump.service.SignRecordService;
import com.jump.service.TaskRecordService;
import com.jump.service.UserInfoService;
import lombok.AllArgsConstructor;
import org.springframework.cglib.core.Local;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.*;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/**
 * 签到记录
 */
@Service
@AllArgsConstructor
public class SignRecordServiceImpl extends ServiceImpl<SignRecordMapper, SignRecord> implements SignRecordService {

    private final SignConfigMapper signConfigMapper;
    private final UserInfoService userInfoService;
    private final RedisTemplate<String, String> redisTemplate;
    private final TaskRecordService taskRecordService;


    @Override
    public SignRecord getSignRecord(String userId) {
        //获取用户的签到记录
        SignRecord signRecord = baseMapper.selectOne(Wrappers.<SignRecord>query().lambda()
                .eq(SignRecord::getUserId, userId));
        if (signRecord == null) {//没有则新增
            signRecord = new SignRecord();
            signRecord.setUserId(userId);
            signRecord.setCumulateDays(0);
            signRecord.setContinuDays(0);
            signRecord.setCreateTime(LocalDateTime.now());
            baseMapper.insert(signRecord);
//        } else if (signRecord.getUpdateTime() != null
//                && !signRecord.getUpdateTime().toLocalDate().equals(LocalDate.now())
//                && !signRecord.getUpdateTime().toLocalDate().equals(LocalDate.now().minusDays(1))) {//判断当天是否是连续天数
//            //最后签到时候不是今天和昨天，则清空连续天数
//            signRecord.setContinuDays(0);
//            baseMapper.updateById(signRecord);
//        }
//        if (signRecord.getUpdateTime() != null
//                && signRecord.getUpdateTime().toLocalDate().equals(LocalDate.now().minusDays(1))) {//最后签到时间为昨天
//            long count = signConfigMapper.selectCount(null);
//            //昨天已经签满，则清空连续天数
//            if (count == signRecord.getContinuDays()) {
//                signRecord.setContinuDays(0);
//                baseMapper.updateById(signRecord);
//            }
        }
        if (signRecord.getUpdateTime() != null
                && signRecord.getUpdateTime().toLocalDate().equals(LocalDate.now())) {
            LocalDateTime now = LocalDateTime.now();
            LocalDateTime nextDayStart = now.plusDays(1).withHour(0).withMinute(0).withSecond(0).withNano(0);
            long secondsBetween = ChronoUnit.SECONDS.between(now, nextDayStart);
            signRecord.setCountdown(secondsBetween);
        }
        return signRecord;
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public SignConfig userSign(String userId) {
        //获取用户的签到记录
        SignRecord signRecord = this.getSignRecord(userId);
        //判断当天是否已经签到过
        if (signRecord.getUpdateTime() == null || !signRecord.getUpdateTime().toLocalDate().equals(LocalDate.now())) {
            //获取签到配置
            Page page = new Page();
            page.setSearchCount(false);
            page.setSize(1);
            page.setCurrent(signRecord.getContinuDays() + 1);
            List<OrderItem> orders = new ArrayList<>();
            OrderItem orderItem = new OrderItem();
            orderItem.setAsc(true);
            orderItem.setColumn("sort");
            page.setOrders(orders);
            List<SignConfig> listSignConfig = signConfigMapper.selectPage(page, null).getRecords();
            if (listSignConfig.size() <= 0) {//已经签满，重头开始
                TaskRecord taskRecord = new TaskRecord();
                taskRecord.setStatus("2");
                taskRecord.setCompleteTime(LocalDateTime.now());
                taskRecord.setCreateTime(LocalDateTime.now());
                taskRecord.setTaskId("4");
                taskRecord.setUpdateTime(LocalDateTime.now());
                taskRecord.setUserId(userId);
                taskRecordService.save(taskRecord);
//                page.setCurrent(1);
//                listSignConfig = signConfigMapper.selectPage(page, null).getRecords();
//                if (listSignConfig.size() <= 0) {
//                    throw new RuntimeException("请在后台设置签到信息");
//                } else {
//                    //重置连续天数
//                    signRecord.setContinuDays(1);
//                }
            } else {
                //连续天数+1
                signRecord.setContinuDays(signRecord.getContinuDays() + 1);
            }
            SignConfig signConfig = listSignConfig.get(0);
            //累计天数+1
            signRecord.setCumulateDays(signRecord.getCumulateDays() + 1);
            ZonedDateTime zonedDateTime = ZonedDateTime.now(ZoneId.systemDefault());
            signRecord.setUpdateTime(LocalDateTime.now());
            baseMapper.updateById(signRecord);
            //更新用户积分
            userInfoService.updatePoints(userId, signConfig.getPosts());
            UserInfo userInfo = userInfoService.getById(userId);
            return signConfig;
        } else {
            return null;
        }
    }

}
