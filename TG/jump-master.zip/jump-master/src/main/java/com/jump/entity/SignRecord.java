
package com.jump.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;


/**
 * 签到记录
 */
@Data
@TableName("sign_record")
@EqualsAndHashCode(callSuper = true)
public class SignRecord extends Model<SignRecord> {
    private static final long serialVersionUID = 1L;

    /**
     * PK
     */
    @TableId(type = IdType.ASSIGN_ID)
    @NotNull(message = "PK不能为空")
    private String id;
    /**
     * 创建时间
     */
    @NotNull(message = "创建时间不能为空")
    private LocalDateTime createTime;
    /**
     * 最后更新（签到）时间
     */
    @NotNull(message = "最后更新（签到）时间不能为空")
    private LocalDateTime updateTime;
    /**
     * 用户ID
     */
    @NotNull(message = "用户ID不能为空")
    private String userId;
    /**
     * 连续天数
     */
    @NotNull(message = "连续天数不能为空")
    private Integer continuDays;
    /**
     * 累计天数
     */
    @NotNull(message = "累计天数不能为空")
    private Integer cumulateDays;

    /**
     * 倒计时
     */
    @TableField(exist = false)
    private Long countdown;

}
