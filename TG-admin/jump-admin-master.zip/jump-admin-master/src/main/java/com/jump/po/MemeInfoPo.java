package com.jump.po;


import lombok.Data;

@Data
public class MemeInfoPo {


    private String id;
    /**
     * 1：审核成功  2 审核失败
     */
    private String status;
}
