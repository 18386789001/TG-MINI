
package com.jump.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jump.annotation.ApiLogin;
import com.jump.constant.R;
import com.jump.entity.SignConfig;
import com.jump.service.SignConfigService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 签到设置
 */
@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/signconfig")
public class SignConfigController {

    private final SignConfigService signConfigService;

    /**
     * 签到配置列表
     * @return
     */
    @GetMapping("/list")
    @ApiLogin
    public R getPage() {
        return R.ok(signConfigService.list(Wrappers.<SignConfig>lambdaQuery().orderByAsc(SignConfig::getSort)));
    }

}
