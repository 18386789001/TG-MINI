package com.jump.config;

import com.jump.service.TaskRecordService;
import lombok.AllArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.core.RedisTemplate;
import org.telegram.telegrambots.bots.DefaultBotOptions;
import org.telegram.telegrambots.meta.TelegramBotsApi;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import org.telegram.telegrambots.updatesreceivers.DefaultBotSession;

@Configuration
@AllArgsConstructor
public class TelegramConfig {

    private final RedisTemplate redisTemplate;
    private final TelegramConfigProperties telegramConfigProperties;
    private final TaskRecordService taskRecordService;


    @Bean
    public void bot() {
        try {
//            String proxyHost = "127.0.0.1";
//            int proxyPort = 7890; // 代理服务器的端口号
//            // 设置系统属性，指定代理服务器
//            System.setProperty("http.proxyHost", proxyHost);
//            System.setProperty("http.proxyPort", String.valueOf(proxyPort));
//            System.setProperty("https.proxyHost", proxyHost);
//            System.setProperty("https.proxyPort", String.valueOf(proxyPort));
            TelegramBotsApi telegramBotsApi = new TelegramBotsApi(DefaultBotSession.class);
            DefaultBotOptions botOptions = new DefaultBotOptions();
//            botOptions.setProxyHost("127.0.0.1");
//            botOptions.setProxyPort(7890);
//            botOptions.setProxyType(DefaultBotOptions.ProxyType.HTTP);
            MyBot myBot = new MyBot(botOptions, redisTemplate,
                    telegramConfigProperties,
                    taskRecordService);
            telegramBotsApi.registerBot(myBot);
        } catch (
                TelegramApiException e) {
            e.printStackTrace();
        }
    }
}
