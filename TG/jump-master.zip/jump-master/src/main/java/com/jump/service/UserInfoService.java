
package com.jump.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.SignConfig;
import com.jump.entity.UserInfo;
import com.jump.po.LoginDTO;
import com.jump.po.ShareInfoVo;
import com.jump.po.UserInfoLoginDTO;

import javax.servlet.http.HttpServletRequest;

/**
 * 签到设置
 */
public interface UserInfoService extends IService<UserInfo> {


    /**
     * 统一更新操作用户积分
     * @param userId 用户ID
     * @param posts 积分变量。+加，-减
     */
    void updatePoints(String userId, Integer posts);

    /**
     * 登录
     * @param request
     * @param userInfoLoginDTO
     * @return
     */
    UserInfo login(HttpServletRequest request, UserInfoLoginDTO userInfoLoginDTO);

    /**
     *
     * @param request
     * @param loginDTO
     * @return
     */
    UserInfo login1(HttpServletRequest request, LoginDTO loginDTO);

    /**
     *
     * @param userId
     * @return
     */
    ShareInfoVo getShareInfo(String userId);

    /**
     *
     */
    void resetHp();

    /**
     *
     */
    void incHp();
}
