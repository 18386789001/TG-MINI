
package com.jump.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jump.entity.SignConfig;

/**
 * 签到设置
 */
public interface SignConfigMapper extends BaseMapper<SignConfig> {

}
