
package com.jump.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.SignConfig;
import com.jump.mapper.SignConfigMapper;
import com.jump.service.SignConfigService;
import org.springframework.stereotype.Service;

/**
 * 签到设置

 */
@Service
public class SignConfigServiceImpl extends ServiceImpl<SignConfigMapper, SignConfig> implements SignConfigService {

}
