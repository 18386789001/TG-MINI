package com.jump;

import cn.hutool.core.lang.UUID;
import cn.hutool.crypto.digest.MD5;
import com.jump.constant.CommonConstants;
import com.jump.util.ThirdSession;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.web.client.RestTemplate;
import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.auth.AccessToken;
import twitter4j.auth.RequestToken;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.Scanner;

@SpringBootTest
public class JumpApplicationTests {

    @Test
    public void contextLoads() {
        ThirdSession thirdSession;
        String key;
        String thirdSessionKey = UUID.randomUUID().toString();

        String token = MD5.create().digestHex(thirdSessionKey);
        System.out.println(token);
//        thirdSession = new ThirdSession();
//        thirdSession.setUserId("1");
        //将3rd_session和用户信息存入redis，并设置过期时间
        key = CommonConstants.THIRD_SESSION_BEGIN + ":" + thirdSessionKey;
//        userInfo.setThirdSession(thirdSessionKey);
//        redisTemplate.opsForValue().set(key, JSONUtil.toJsonStr(thirdSession), MallConstants.TIME_OUT_SESSION, TimeUnit.HOURS);
//        return userInfo;

    }

    @Test
    public void aa() {

        System.setProperty("http.proxyHost", "127.0.0.1");
        System.setProperty("http.proxyPort", "7890");


        // 创建 Twitter 实例
        Twitter twitter = TwitterFactory.getSingleton();
        // 设置 Consumer Key 和 Consumer Secret
        twitter.setOAuthConsumer("993XyLfYamZv0lSpjKZK7af9r", "cFA8S2mLfCvLxwgKJpvDPBKCdmzIetdDebU1z3nJBKX1QUMAp1");

        try {
            // 获取 Request Token
            RequestToken requestToken = twitter.getOAuthRequestToken();
            AccessToken accessToken = null;


            // 获取授权 URL
            String authorizationURL = requestToken.getAuthorizationURL();

            // 打开浏览器，让用户登录并授权
            System.out.println("Please go to the following URL to authorize:");
            System.out.println(authorizationURL);

            // 获取用户输入的 PIN
            System.out.print("Enter the PIN: ");
            Scanner scanner = new Scanner(System.in);
            String pin = scanner.nextLine();
        } catch (TwitterException te) {
            te.printStackTrace();
        }
    }


    private final String botToken = "7478309203:AAGKvCvWygOOuCq-FVHvQ4sqDhOriohh_xQ";
    private final String baseUrl = "https://api.telegram.org/bot" + botToken;

    @Test
    public void bb() {
        String proxyHost = "127.0.0.1";
        int proxyPort = 7890; // 代理服务器的端口号
        // 设置系统属性，指定代理服务器
        System.setProperty("http.proxyHost", proxyHost);
        System.setProperty("http.proxyPort", String.valueOf(proxyPort));
        System.setProperty("https.proxyHost", proxyHost);
        System.setProperty("https.proxyPort", String.valueOf(proxyPort));
        RestTemplate restTemplate = new RestTemplate();
        String url = baseUrl + "/getUpdates";
        String response = restTemplate.getForObject(url, String.class);
        System.out.println(response);
        // 解析 response，获取 chatId
        // 这里简单示例，实际中需要根据 Telegram Bot API 返回的 JSON 结构解析
        // 假设 response 是 JSON 格式，可以使用 JSON 解析库解析
        // 示例中简单地从 response 中获取 chatId，实际中需要根据 Telegram Bot API 的返回结构来处理
        String chatId = "123456789"; // 从 response 中解析出 chatId

}

}
