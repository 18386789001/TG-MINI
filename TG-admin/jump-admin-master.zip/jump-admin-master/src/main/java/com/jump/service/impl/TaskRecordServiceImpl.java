package com.jump.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.TaskRecord;
import com.jump.mapper.TaskRecordMapper;
import com.jump.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 任务完成记录
 *
 * @date 2024-06-30 21:11:36
 */
@Service
public class TaskRecordServiceImpl extends ServiceImpl<TaskRecordMapper, TaskRecord> implements TaskRecordService {

    @Autowired
    private PostInfoService postInfoService;
    @Autowired
    private MemeInfoService memeInfoService;
    @Autowired
    private UserInfoService userInfoService;
    @Autowired
    private TaskInfoService taskInfoService;

}
