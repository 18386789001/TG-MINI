package com.jump.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jump.constant.R;
import com.jump.entity.PostInfo;
import com.jump.po.PostInfoPo;
import com.jump.service.PostInfoService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/postinfo")
public class PostInfoController {

    @Autowired
    private PostInfoService postInfoService;

    @GetMapping("/page")
    public R page(Page page, PostInfo postInfo) {
        return R.ok(postInfoService.page(page, Wrappers.<PostInfo>lambdaQuery().eq(PostInfo::getStatus, "0")));
    }

    @PostMapping("/verify")
    public R verify(@RequestBody PostInfoPo postInfoPo) {
        return R.ok(postInfoService.verify(postInfoPo));
    }


}
