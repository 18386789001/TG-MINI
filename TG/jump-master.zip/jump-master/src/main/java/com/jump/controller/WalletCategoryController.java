package com.jump.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jump.annotation.ApiLogin;
import com.jump.constant.R;
import com.jump.entity.WalletCategory;
import com.jump.service.WalletCategoryService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 钱包分类表
 *
 * @date 2024-07-11 21:23:27
 */
@Slf4j
@RestController
@RequestMapping("/walletcategory")
public class WalletCategoryController {

    @Autowired
    private WalletCategoryService walletCategoryService;

    /**
     * 钱包分类表分页列表
     *
     * @param walletCategory 钱包分类表
     * @return
     */
    @GetMapping("/list")
    @ApiLogin
    public R list(WalletCategory walletCategory) {
        return R.ok(walletCategoryService.list(Wrappers.query(walletCategory)));
    }


}
