package com.jump.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.ShareRecord;
import com.jump.mapper.ShareRecordMapper;
import com.jump.po.ShareInfoVo;
import com.jump.service.ShareRecordService;
import org.springframework.stereotype.Service;

/**
 * 分享记录
 *
 * @date 2024-07-06 03:47:29
 */
@Service
public class ShareRecordServiceImpl extends ServiceImpl<ShareRecordMapper, ShareRecord> implements ShareRecordService {
}
