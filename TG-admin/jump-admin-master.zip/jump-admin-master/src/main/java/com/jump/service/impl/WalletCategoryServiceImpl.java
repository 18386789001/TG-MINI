package com.jump.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.WalletCategory;
import com.jump.mapper.WalletCategoryMapper;
import com.jump.service.WalletCategoryService;
import org.springframework.stereotype.Service;

/**
 * 钱包分类表
 *
 * @date 2024-07-11 21:23:27
 */
@Service
public class WalletCategoryServiceImpl extends ServiceImpl<WalletCategoryMapper, WalletCategory> implements WalletCategoryService {

}
