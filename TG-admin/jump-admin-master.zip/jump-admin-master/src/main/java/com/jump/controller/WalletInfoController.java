package com.jump.controller;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jump.constant.R;
import com.jump.entity.WalletInfo;
import com.jump.service.WalletInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 钱包
 *
 * @date 2024-07-03 22:07:39
 */
@Slf4j
@RestController
@RequestMapping("/walletinfo")
public class WalletInfoController {

    @Autowired
    private WalletInfoService walletInfoService;

    /**
     * 钱包分页列表
     *
     * @param
     * @return
     */
    @GetMapping("page")
    public R getList(Page page, WalletInfo walletInfo) {
        return R.ok(walletInfoService.page(page, Wrappers.<WalletInfo>lambdaQuery(walletInfo)));
    }

}
