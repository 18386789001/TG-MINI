
package com.jump.service.impl;

import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.config.BizException;
import com.jump.constant.CommonConstants;
import com.jump.entity.*;
import com.jump.mapper.SignConfigMapper;
import com.jump.mapper.UserInfoMapper;
import com.jump.po.LoginDTO;
import com.jump.po.ShareInfoVo;
import com.jump.po.UserInfoLoginDTO;
import com.jump.service.*;
import com.jump.util.ThirdSession;
import com.jump.util.UniqueCodeGeneratorUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * 签到设置
 */
@Slf4j
@Service
public class UserInfoServiceImpl extends ServiceImpl<UserInfoMapper, UserInfo> implements UserInfoService {


    @Autowired
    private RedisTemplate redisTemplate;
    @Autowired
    private ShareConfigService shareConfigService;
    @Autowired
    private TaskConfigService taskConfigService;
    @Autowired
    private ShareRecordService shareRecordService;

    @Override
    @Transactional(rollbackFor = Exception.class)

    public void updatePoints(String userId, Integer posts) {
        baseMapper.update(new UserInfo(), Wrappers.<UserInfo>lambdaUpdate()
                .eq(UserInfo::getId, userId)
                .setSql(" points = points + " + posts));
    }

    @Override
    public UserInfo login(HttpServletRequest request, UserInfoLoginDTO userInfoLoginDTO) {
        UserInfo userInfo1 = baseMapper.selectOne(Wrappers.<UserInfo>lambdaQuery().eq(UserInfo::getChatId, userInfoLoginDTO.getId()));
        if (userInfo1 == null) {
//            String userName = (String) redisTemplate.opsForValue().get("user:" + userInfoLoginDTO.getChatId());
//            if (userName == null) {
//                throw new BizException("error");
//            }
            TaskConfig taskConfig = taskConfigService.getOne(Wrappers.query());
            LocalDateTime localDateTime = LocalDateTime.now();
            LocalDateTime time = localDateTime.plusHours(taskConfig.getEffectiveTime());
            userInfo1 = new UserInfo();
            userInfo1.setPoints(0);
            userInfo1.setParentId("0");
            userInfo1.setHeadimgUrl(userInfoLoginDTO.getPhoto_url());
            userInfo1.setCreateTime(LocalDateTime.now());
            userInfo1.setUpdateTime(LocalDateTime.now());
            userInfo1.setChatId(userInfoLoginDTO.getId());
            userInfo1.setUserName(userInfoLoginDTO.getFirst_name() + " " + userInfoLoginDTO.getLast_name());
            userInfo1.setUserCode(UniqueCodeGeneratorUtils.generateSixDigitCode());
            userInfo1.setTaskTime(time.toEpochSecond(ZoneOffset.UTC));
            userInfo1.setHp(5);
            if (!StrUtil.isEmpty(userInfoLoginDTO.getSharerUserCode())) {
                UserInfo userInfo = baseMapper.selectOne(Wrappers.<UserInfo>lambdaQuery()
                        .eq(UserInfo::getUserCode, userInfoLoginDTO.getSharerUserCode()));
                if (userInfo != null) {
                    ShareConfig shareConfig = shareConfigService.getOne(Wrappers.query());
                    userInfo1.setParentId(userInfo.getId());
                    userInfo1.setPoints(shareConfig.getPoints());
                    BigDecimal sharerPoints = BigDecimal.valueOf(shareConfig.getPoints()).multiply(shareConfig.getScale());
                    String a = sharerPoints.toPlainString();
                    int dotIndex = a.indexOf(".");
                    String integerPart = a.substring(0, dotIndex);
                    userInfo.setPoints(userInfo.getPoints() + Integer.valueOf(integerPart));
                    baseMapper.updateById(userInfo);
                }
            }
            baseMapper.insert(userInfo1);
        }
        ThirdSession thirdSession;
        String key;
        String thirdSessionKey = UUID.randomUUID().toString().replace("-", "");
        thirdSession = new ThirdSession();
        thirdSession.setUserId(userInfo1.getId());
        //将3rd_session和用户信息存入redis，并设置过期时间
        key = CommonConstants.THIRD_SESSION_BEGIN + ":" + thirdSessionKey;
        userInfo1.setThirdSession(thirdSessionKey);
        redisTemplate.opsForValue().set(key, JSONUtil.toJsonStr(thirdSession));
        return userInfo1;
    }


    @Override
    @Transactional
    public UserInfo login1(HttpServletRequest request, LoginDTO loginDTO) {
        UserInfo userInfo = baseMapper.selectOne(Wrappers.<UserInfo>lambdaQuery().eq(UserInfo::getChatId, loginDTO.getChatId()));
        if (userInfo == null) {
            String user = (String) redisTemplate.opsForValue().get("user:" + loginDTO.getChatId());
            Long chatId = loginDTO.getChatId();
            String userName = loginDTO.getUserName();
            Long sharerChatId = null;
            if (!StrUtil.isEmpty(user)) {
                Map<String, String> map = JSONUtil.toBean(user, HashMap.class);
                chatId = Long.valueOf(map.get("chatId"));
                userName = map.get("userName");
                if (!StrUtil.isEmpty(map.get("sharerChatId"))) {
                    sharerChatId = Long.valueOf(map.get("sharerChatId"));
                }
            }
            if (StrUtil.isEmpty(userName)) {
                userName = chatId + "";
            }
            TaskConfig taskConfig = taskConfigService.getOne(Wrappers.query());
            LocalDateTime localDateTime = LocalDateTime.now();
            LocalDateTime time = localDateTime.plusHours(taskConfig.getEffectiveTime());
            userInfo = new UserInfo();
            userInfo.setPoints(0);
            userInfo.setParentId("0");
            userInfo.setHeadimgUrl("https://open.zhimulp.online/images1810340661673725952.jpg");
            userInfo.setCreateTime(LocalDateTime.now());
            userInfo.setUpdateTime(LocalDateTime.now());
            userInfo.setChatId(chatId);
            userInfo.setUserName(userName);
            userInfo.setUserCode(UniqueCodeGeneratorUtils.generateSixDigitCode());
            userInfo.setTaskTime(time.toEpochSecond(ZoneOffset.UTC));
            userInfo.setHp(8);
            userInfo.setIsNewUser("1");
            baseMapper.insert(userInfo);
            if (sharerChatId != null) {
                UserInfo userInfo1 = baseMapper.selectOne(Wrappers.<UserInfo>lambdaQuery()
                        .eq(UserInfo::getChatId, sharerChatId));
                if (userInfo1 != null) {
                    ShareConfig shareConfig = shareConfigService.getOne(Wrappers.query());
                    userInfo1.setPoints(userInfo1.getPoints()+ shareConfig.getPoints());
                    userInfo1.setHp(userInfo1.getHp() + 1);
                    baseMapper.updateById(userInfo1);
                    if (!StrUtil.isEmpty(userInfo1.getParentId())) {
                        System.out.println("------------------------------------------------");
                        BigDecimal sharerPoints = BigDecimal.valueOf(shareConfig.getPoints()).multiply(shareConfig.getScale());
                        String a = sharerPoints.toPlainString();
                        int dotIndex = a.indexOf(".");
                        String integerPart = a.substring(0, dotIndex);
                        UserInfo userInfo2 = baseMapper.selectById(userInfo1.getParentId());
                        if (userInfo2 != null){
                            System.out.println("=============================================");
                            userInfo2.setPoints(userInfo2.getPoints() + Integer.valueOf(integerPart));
                            baseMapper.updateById(userInfo2);
                            ShareRecord shareRecord2 = new ShareRecord();
                            shareRecord2.setUserId(userInfo2.getId());
                            shareRecord2.setShareUserId(userInfo2.getId());
                            shareRecord2.setPoints(Integer.valueOf(integerPart));
                            shareRecord2.setCreateTime(LocalDateTime.now());
                            shareRecord2.setUpdateTime(LocalDateTime.now());
                            shareRecordService.save(shareRecord2);
                        }
                    }
                    ShareRecord shareRecord = new ShareRecord();
                    shareRecord.setUserId(userInfo1.getId());
                    shareRecord.setShareUserId(userInfo1.getId());
                    shareRecord.setPoints(shareConfig.getPoints());
                    shareRecord.setCreateTime(LocalDateTime.now());
                    shareRecord.setUpdateTime(LocalDateTime.now());
                    shareRecordService.save(shareRecord);
                    userInfo.setParentId(userInfo1.getId());
                }
                baseMapper.updateById(userInfo);
            }
            redisTemplate.delete("user:" + loginDTO.getChatId());
        }
        ThirdSession thirdSession;
        String key;
        String thirdSessionKey = UUID.randomUUID().toString();
        thirdSession = new ThirdSession();
        thirdSession.setUserId(userInfo.getId());
        //将3rd_session和用户信息存入redis，并设置过期时间
        key = CommonConstants.THIRD_SESSION_BEGIN + ":" + thirdSessionKey;
        userInfo.setThirdSession(thirdSessionKey);
        redisTemplate.opsForValue().set(key, JSONUtil.toJsonStr(thirdSession), 604800L, TimeUnit.SECONDS);
        return userInfo;
    }


    @Override
    public ShareInfoVo getShareInfo(String userId) {
        List<ShareRecord> shareRecords = shareRecordService.list(Wrappers.<ShareRecord>lambdaQuery().eq(ShareRecord::getUserId, userId));
        ShareInfoVo shareInfoVo = new ShareInfoVo();
        shareInfoVo.setPeopleNumber(shareRecords.size());
        shareInfoVo.setPoints(shareRecords.stream().mapToInt(ShareRecord::getPoints).sum());
        return shareInfoVo;
    }


    @Override
    public void resetHp() {
        baseMapper.update(new UserInfo(), Wrappers.<UserInfo>lambdaUpdate()
                .setSql(" hp = 8 "));
        log.info("重置成功");
    }

    @Override
    public void incHp() {
        LocalDateTime dateTime = LocalDateTime.now(); // 示例：当前日期和时间
        // 判断是否为午夜0时
        if (!dateTime.toLocalTime().equals(LocalTime.MIN)) {
            baseMapper.update(new UserInfo(), Wrappers.<UserInfo>lambdaUpdate()
                    .setSql(" hp = hp+1 ")
                    .lt(UserInfo::getHp, 8));
            log.info("更新成功");
        }


    }
}

