package com.jump.entity;


import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;
import java.util.List;

@Data
@TableName("user_info")
@EqualsAndHashCode(callSuper = true)
public class UserInfo extends Model<SignConfig> {

    @TableId(type = IdType.ASSIGN_ID)
    private String id;

    private String userName;

    private Integer points;


    /**
     * 头像
     */
    private String headimgUrl;
    /**
     * 上级ID
     */
    private String parentId;
    /**
     * 创建时间
     */
    private LocalDateTime createTime;
    /**
     * 最后更新时间
     */
    private LocalDateTime updateTime;
    /**
     * 用户编码
     */
    private String userCode;


    private String token;

    private Integer hp;


    private Long chatId;

    private Long taskTime;

    @TableField(exist = false)
    private String thirdSession;

    @TableField(exist = false)
    private String walletUrl;

    @TableField(exist = false)
    private List<String> walletUrlList;

    @TableField(exist = false)
    private String isNewUser = "0";

}
