package com.jump.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jump.constant.R;
import com.jump.entity.TaskRecord;
import com.jump.service.TaskRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * 任务完成记录
 *
 * @date 2024-06-30 21:11:36
 */
@Slf4j
@RestController
@RequestMapping("/taskrecord")
public class TaskRecordController {

    @Autowired
    private TaskRecordService taskRecordService;

    /**
     * 任务完成记录分页列表
     *
     * @param page       分页对象
     * @param taskRecord 任务完成记录
     * @return
     */
    @GetMapping("/page")
    public R getPage(Page page, TaskRecord taskRecord) {
        return R.ok(taskRecordService.page(page, Wrappers.query(taskRecord)));
    }



}
