package com.jump.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.WalletInfo;
import com.jump.mapper.WalletInfoMapper;
import com.jump.service.WalletInfoService;
import org.springframework.stereotype.Service;

/**
 * 钱包
 *
 * @date 2024-07-03 22:07:39
 */
@Service
public class WalletInfoServiceImpl extends ServiceImpl<WalletInfoMapper, WalletInfo> implements WalletInfoService {

}
