package com.jump.service;

import com.jump.entity.UserInfo;
import com.jump.po.GameRecordPo;


public interface GameService {

    /**
     * 开始游戏
     * @param userInfo
     * @return
     */
    Boolean start(UserInfo userInfo);

    /**
     * 游戏通过
     * @param userInfo
     * @return
     */
    Boolean clearance(UserInfo userInfo,GameRecordPo gameRecordPo);

    /**
     *
     * @param userInfo
     * @param gameRecordPo
     * @return
     */
    Boolean record(UserInfo userInfo, GameRecordPo gameRecordPo);
}
