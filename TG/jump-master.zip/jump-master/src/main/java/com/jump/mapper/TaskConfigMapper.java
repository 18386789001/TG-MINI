package com.jump.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jump.entity.TaskConfig;

/**
 * 任务配置
 *
 * @date 2024-07-04 23:05:49
 */
public interface TaskConfigMapper extends BaseMapper<TaskConfig> {

}
