package com.jump.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.TaskRecord;
import com.jump.po.TaskRecordPo;

/**
 * 任务完成记录
 *
 * @date 2024-06-30 21:11:36
 */
public interface TaskRecordService extends IService<TaskRecord> {


    Boolean add(TaskRecordPo taskRecordPo);

    /**
     * 处理加入群聊
     * @param id
     */
    void handel(Long id);

    void handMessage(Long id);


    Boolean joinChannel(TaskRecordPo taskRecordPo);

    Boolean followX(TaskRecordPo taskRecordPo);



    Boolean confirmCompletion(TaskRecordPo taskRecordPo);
}
