package com.jump.constant;

public interface CommonConstants {


    long TIME_OUT_SESSION = -1;

    /**
     * redis中3rd_session拼接前缀
     */
    String THIRD_SESSION_BEGIN = "app:3rd_session";
    /**
     * header中的third-session
     */
    String HEADER_THIRDSESSION = "third-session";
    /**
     *
     */
    String HEADER_AUTHORIZATION = "Authorization";



    /**
     * 是
     */
    String YES = "1";
    /**
     * 否
     */
    String NO = "0";
    /**
     * header 中租户ID
     */
    String TENANT_ID = "tenant-id";
    /**
     * header 中Authorization
     */
    String AUTHORIZATION = "Authorization";
    /**
     * 删除
     */
    String STATUS_DEL = "1";
    /**
     * 正常
     */
    String STATUS_NORMAL = "0";
    /**
     * 锁定
     */
    String STATUS_LOCK = "9";
    /**
     * 日志类型：正常操作日志
     */
    String LOG_TYPE_0 = "0";
    /**
     * 日志类型：异常操作日志
     */
    String LOG_TYPE_9 = "9";

    /**
     * 成功标记
     */
    Integer SUCCESS = 200;
    /**
     * 失败标记
     */
    Integer FAIL = 500;

    /**
     * 树形父类ID
     */
    String PARENT_ID = "0";
    /**
     * 编码
     */
    String UTF8 = "UTF-8";

    /**
     * 手机验证码类型（1、登录；2、绑定手机号/注册；3、解绑手机；4、重置密码）
     */
    String PHONE_CODE_1 = "1";
    String PHONE_CODE_2 = "2";
    String PHONE_CODE_3 = "3";
    String PHONE_CODE_4 = "4";


    /**
     * 默认验证码前缀
     */
    String VER_CODE_DEFAULT = "ver_code_default:";

    /**
     * 验证码有效期（5分钟）
     */
    int CODE_TIME = 300;
    /**
     * 验证码长度
     */
    String CODE_SIZE = "4";

}
