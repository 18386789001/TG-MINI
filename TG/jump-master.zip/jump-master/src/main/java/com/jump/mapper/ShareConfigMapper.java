package com.jump.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jump.entity.ShareConfig;

/**
 * 分享配置
 *
 * @date 2024-06-30 21:11:22
 */
public interface ShareConfigMapper extends BaseMapper<ShareConfig> {

}
