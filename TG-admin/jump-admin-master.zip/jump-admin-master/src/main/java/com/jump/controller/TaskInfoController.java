package com.jump.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jump.constant.R;
import com.jump.entity.TaskInfo;
import com.jump.service.TaskInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 任务
 *
 * @date 2024-06-30 21:10:46
 */
@Slf4j
@RestController
@RequestMapping("/taskinfo")
public class TaskInfoController {

    @Autowired
    private TaskInfoService taskInfoService;

    /**
     * 任务分页列表
     * @param page 分页对象
     * @param taskInfo 任务
     * @return
     */
    @GetMapping("/page")
    public R getPage(Page page, TaskInfo taskInfo) {
        return R.ok(taskInfoService.page(page, Wrappers.query(taskInfo)));
    }

    /**
     * 修改
     * @param page
     * @param taskInfo
     * @return
     */
    @PostMapping("/update")
    public R update(@RequestBody TaskInfo taskInfo) {
        return R.ok(taskInfoService.updateById(taskInfo));
    }







}
