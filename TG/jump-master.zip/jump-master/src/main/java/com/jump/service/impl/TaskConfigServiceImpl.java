package com.jump.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.TaskConfig;
import com.jump.mapper.TaskConfigMapper;
import com.jump.service.TaskConfigService;
import org.springframework.stereotype.Service;

/**
 * 任务配置
 *
 * @date 2024-07-04 23:05:49
 */
@Service
public class TaskConfigServiceImpl extends ServiceImpl<TaskConfigMapper, TaskConfig> implements TaskConfigService {

}
