package com.jump.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.TaskInfo;

import java.util.List;

/**
 * 任务
 *
 * @date 2024-06-30 21:10:46
 */
public interface TaskInfoService extends IService<TaskInfo> {

    IPage<TaskInfo> page1(Page page, QueryWrapper<TaskInfo> query);

    IPage<TaskInfo> getCompletedPage(Page page, QueryWrapper<TaskInfo> query);

    List<TaskInfo> page2(QueryWrapper<TaskInfo> query);
}
