package com.jump.po;

import lombok.Data;

@Data
public class MemeInfoPo {

    /**
     * 内容
     */
    private String postContent;

    /**
     * taskType
     * 任务类型
     */
    private String taskType;

    /**
     * taskId
     */
    private String taskId;

}
