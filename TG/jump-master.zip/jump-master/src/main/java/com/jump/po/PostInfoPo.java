package com.jump.po;

import lombok.Data;

@Data
public class PostInfoPo {

    /**
     * 内容
     */
    private String postContent;

    /**
     * 图片
     */
    private String imgUrl;

    /**
     * taskType
     * 任务类型
     */
    private String taskType;

    /**
     * taskId
     */
    private String taskId;

    /**
     * 类型
     */
    private String type;
}
