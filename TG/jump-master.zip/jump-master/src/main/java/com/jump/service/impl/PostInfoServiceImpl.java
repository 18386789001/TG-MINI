package com.jump.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jump.entity.PostInfo;
import com.jump.entity.TaskRecord;
import com.jump.mapper.PostInfoMapper;
import com.jump.po.PostInfoPo;
import com.jump.service.PostInfoService;
import com.jump.service.TaskInfoService;
import com.jump.service.TaskRecordService;
import com.jump.util.ThirdSessionHolder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class PostInfoServiceImpl extends ServiceImpl<PostInfoMapper, PostInfo> implements PostInfoService {

    @Autowired
    private TaskInfoService taskInfoService;
    @Autowired
    private TaskRecordService taskRecordService;

    @Override
    @Transactional
    public Boolean submit(PostInfoPo postInfoPo) {
        PostInfo postInfo = new PostInfo();
        postInfo.setPostContent(postInfoPo.getPostContent());
        postInfo.setImgUrl(postInfoPo.getImgUrl());
        postInfo.setType(postInfoPo.getType());
        postInfo.setCreateTime(LocalDateTime.now());
        postInfo.setUpdateTime(LocalDateTime.now());
        postInfo.setUserId(ThirdSessionHolder.getUserId());
        postInfo.setTaskId(postInfoPo.getTaskId());
        Boolean boo = super.save(postInfo);
        if (boo) {
            TaskRecord taskRecord = new TaskRecord();
            taskRecord.setCompleteTime(LocalDateTime.now());
            taskRecord.setCreateTime(LocalDateTime.now());
             taskRecord.setStatus("1");
            taskRecord.setTaskId(postInfoPo.getTaskId());
            taskRecord.setUserId(ThirdSessionHolder.getUserId());
            taskRecordService.save(taskRecord);
        }
//        return super.save(postInfo);
        return boo;
    }
}
