package com.jump.service;

public interface TwitterService {
}
