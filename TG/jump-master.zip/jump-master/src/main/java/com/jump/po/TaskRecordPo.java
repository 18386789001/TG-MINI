package com.jump.po;

import lombok.Data;

@Data
public class TaskRecordPo {


    private String postContent;

    /**
     * 图片
     */
    private String imgUrl;

    /**
     * taskType
     * 任务类型 1：加入电报  2：加入电报聊天  3：关注X  5：点赞评论X   6：Add $ Dawg to X name  7：Make a post about $DAWG  8:submit a DAWG meme;;
     */
    private String taskType;

    /**
     * taskId
     */
    private String taskId;
}
