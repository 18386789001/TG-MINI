package com.jump.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

/**
 * 任务完成记录
 *
 * @date 2024-06-30 21:11:36
 */
@Data
@TableName("task_record")
@EqualsAndHashCode(callSuper = true)
public class TaskRecord extends Model<TaskRecord> {
    private static final long serialVersionUID = 1L;

    /**
     * Pk
     */
    @TableId(type = IdType.ASSIGN_ID)
    @NotNull(message = "Pk不能为空")
    private String id;

    private String userId;
    /**
     * 任务id
     */
    @NotNull(message = "任务id不能为空")
    private String taskId;
    /**
     * 状态 1、进行中 2、已完成
     */
    @NotNull(message = "状态 1、进行中 2、已完成不能为空")
    private String status;
    /**
     * 完成时间
     */
    @NotNull(message = "完成时间不能为空")
    private LocalDateTime completeTime;
    /**
     * 创建时间
     */
    @NotNull(message = "创建时间不能为空")
    private LocalDateTime createTime;
    /**
     * 修改时间
     */
    private LocalDateTime updateTime;

}
