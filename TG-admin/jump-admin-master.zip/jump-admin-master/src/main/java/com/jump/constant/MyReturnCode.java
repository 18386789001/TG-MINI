package com.jump.constant;
public enum MyReturnCode {

	ERR_60000(60000, "系统错误，请稍候再试"){},//其它错误
	ERR_60001(60001, "登录超时，请重新登录"){},
	ERR_60002(60002, "session不能为空"){},
	ERR_60003(60003, "请先登录"){},

	ERR_70000(70000, "系统错误，请稍候再试"){},//其它错误
	ERR_70002(70002, "请选择付款方式"){},
	ERR_70006(70006, "该手机号已注册，请直接登录"){},
	ERR_70007(70007, "该手机号未注册"){},
	ERR_70008(70008, "验证码发送过频繁，请稍后再试"){},
	ERR_70009(70009, "验证码不合法"){},
	ERR_70010(70010, "账号或密码错误"){},
	;

	MyReturnCode(int code, String msg) {
		this.code = code;
		this.msg = msg;
	}

	private int code;
	private String msg;

	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "MyReturnCode{" + "code='" + code + '\'' + "msg='" + msg + '\'' + '}';
	}

}
