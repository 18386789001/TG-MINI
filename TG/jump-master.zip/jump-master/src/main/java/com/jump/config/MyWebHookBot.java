package com.jump.config;

import org.telegram.telegrambots.bots.TelegramWebhookBot;
import org.telegram.telegrambots.meta.api.methods.BotApiMethod;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.Update;

//public class MyWebHookBot extends TelegramWebhookBot {
//
//    private String token = "7377159462:AAFZ4363siSyEYVzJjFwe69m1lu0I5Xmonk";
//    private String botUsername = "Lililia_bot";
//
//
//    @Override
//    public String getBotUsername() {
//        return this.botUsername;
//    }
//
//    @Override
//    public String getBotToken() {
//        return this.token;
//    }
//
//    @Override
//    public BotApiMethod<?> onWebhookUpdateReceived(Update update) {
//        return SendMessage.builder().chatId(update.getMessage().getChatId()).text("Halo!").build();
//    }
//
//    @Override
//    public String getBotPath() {
//        return this.botUsername;
//    }
//}
