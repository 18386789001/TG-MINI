package com.jump.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.validation.constraints.NotNull;

/**
 * 
 *
 * @date 2024-07-06 21:16:02
 */
@Data
@TableName("game_config")
@EqualsAndHashCode(callSuper = true)
public class GameConfig extends Model<GameConfig> {
    private static final long serialVersionUID=1L;

    /**
     * PK
     */
    @TableId(type = IdType.AUTO)
    @NotNull(message = "PK不能为空")
    private String id;
    /**
     * 需要生命值
     */
    @NotNull(message = "需要生命值不能为空")
    private Integer hp;
    /**
     * 通关获得积分
     */
    @NotNull(message = "通关获得积分不能为空")
    private Integer points;
    /**
     * 上限次数
     */
    @NotNull(message = "上限次数不能为空")
    private Integer mapTimes;

}
