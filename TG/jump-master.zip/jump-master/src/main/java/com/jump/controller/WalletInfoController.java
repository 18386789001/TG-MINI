package com.jump.controller;

import cn.hutool.core.util.StrUtil;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.jump.annotation.ApiLogin;
import com.jump.constant.R;
import com.jump.entity.WalletInfo;
import com.jump.service.WalletInfoService;
import com.jump.util.ThirdSessionHolder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

/**
 * 钱包
 *
 * @date 2024-07-03 22:07:39
 */
@Slf4j
@RestController
@RequestMapping("/walletinfo")
public class WalletInfoController {

    @Autowired
    private WalletInfoService walletInfoService;

    /**
     * 钱包分页列表
     *
     * @param
     * @return
     */
    @GetMapping("get")
    @ApiLogin
    public R getPage() {
        return R.ok(walletInfoService.getOne(Wrappers.<WalletInfo>lambdaQuery()
                .eq(WalletInfo::getUserId, ThirdSessionHolder.getUserId())));
    }


    /**
     * 钱包分页列表
     *
     * @param
     * @return
     */
    @GetMapping("getList")
    @ApiLogin
    public R getList(WalletInfo walletInfo) {
        return R.ok(walletInfoService.list(Wrappers.<WalletInfo>lambdaQuery()
                .eq(WalletInfo::getUserId, ThirdSessionHolder.getUserId())
                .eq(!StrUtil.isEmpty(walletInfo.getWalletCategoryId()),WalletInfo::getWalletCategoryId,walletInfo.getWalletCategoryId())));
    }

    /**
     * 钱包新增
     *
     * @param walletInfo 钱包
     * @return R
     */
    @PostMapping
    @ApiLogin
    public R save(@RequestBody WalletInfo walletInfo) {
        walletInfo.setCreateTime(LocalDateTime.now());
        walletInfo.setUpdateTime(LocalDateTime.now());
        walletInfo.setUserId(ThirdSessionHolder.getUserId());
        return R.ok(walletInfoService.save(walletInfo));
    }


    /**
     * 钱包新增
     *
     * @param walletInfo 钱包
     * @return R
     */
    @PostMapping("/update")
    @ApiLogin
    public R update(@RequestBody WalletInfo walletInfo) {
        walletInfo.setUpdateTime(LocalDateTime.now());
        return R.ok(walletInfoService.updateById(walletInfo));
    }


}
