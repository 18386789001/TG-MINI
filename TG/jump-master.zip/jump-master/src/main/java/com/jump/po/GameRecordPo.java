package com.jump.po;

import lombok.Data;

/**
 * @author :
 * @date : 2024/6/28  9:43
 */
@Data
public class GameRecordPo {

    /**
     * 次数
     */
    private Integer times;

}
