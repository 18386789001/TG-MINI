package com.jump.po;

import lombok.Data;

@Data
public class LoginDTO {

    private Long chatId;
    private String userName;
}
