package com.jump.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.GameRecord;

/**
 * @author :
 * @date : 2024/6/28  11:22
 */
public interface GameRecordService extends IService<GameRecord> {
}
