package com.jump.controller;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jump.annotation.ApiLogin;
import com.jump.constant.R;
import com.jump.entity.TaskInfo;
import com.jump.service.TaskInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * 任务
 *
 * @date 2024-06-30 21:10:46
 */
@Slf4j
@RestController
@RequestMapping("/taskinfo")
public class TaskInfoController {

    @Autowired
    private TaskInfoService taskInfoService;

    /**
     * 任务分页列表
     *
     * @param page     分页对象
     * @param taskInfo 任务
     * @return
     */
    @GetMapping("/page")
    @ApiLogin
    public R getPage(Page page, TaskInfo taskInfo) {
        return R.ok(taskInfoService.page1(page, Wrappers.query(taskInfo)));
    }


    /**
     * 任务分页列表
     *
     * @param page     分页对象
     * @param taskInfo 任务
     * @return
     */
    @GetMapping("/completedPage")
    @ApiLogin
    public R getCompletedPage(Page page, TaskInfo taskInfo) {
        return R.ok(taskInfoService.getCompletedPage(page, Wrappers.query(taskInfo)));
    }


    /**
     * 任务分页列表
     *
     * @param page     分页对象
     * @param taskInfo 任务
     * @return
     */
    @GetMapping("/homePage")
    @ApiLogin
    public R getHomePage(TaskInfo taskInfo) {
        return R.ok(taskInfoService.page2(Wrappers.query(taskInfo)));
    }


    /**
     * aaa
     */
    @GetMapping("/test")
    public R test() {
        return R.ok(LocalDateTime.now());
    }


}
