package com.jump.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.baomidou.mybatisplus.extension.activerecord.Model;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;

@Data
@TableName("meme_info")
@EqualsAndHashCode(callSuper = true)
public class MemeInfo extends Model<MemeInfo> {

    @TableId(type = IdType.ASSIGN_ID)
    private String id;
    private String userId;
    private String taskId;
    private String postContent;
    private String status;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
