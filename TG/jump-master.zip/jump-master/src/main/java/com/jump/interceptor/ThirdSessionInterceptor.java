
package com.jump.interceptor;


import cn.hutool.core.util.StrUtil;
import cn.hutool.json.JSONUtil;
import com.jump.annotation.ApiLogin;
import com.jump.constant.CommonConstants;
import com.jump.constant.MyReturnCode;
import com.jump.constant.R;
import com.jump.util.ThirdSession;
import com.jump.util.ThirdSessionHolder;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.AsyncHandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.TimeUnit;

/**
 * ThirdSession拦截器，校验每个请求的ThirdSession
 *

 */
@Slf4j
@Component
@AllArgsConstructor
public class ThirdSessionInterceptor implements AsyncHandlerInterceptor {

    private final RedisTemplate redisTemplate;


    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        HandlerMethod method = (HandlerMethod) handler;
        //判断访问的control是否添加ApiLogin注解
        ApiLogin apiLogin = method.getMethodAnnotation(ApiLogin.class);
        //只对@ApiLogin注解的接口进行Session校验
        if (apiLogin != null && apiLogin.mustLogin()) {//此接口必须登录才能访问
            return this.judeSession(request, response, apiLogin);
        } else {
            String thirdSessionHeader = request.getHeader(CommonConstants.HEADER_AUTHORIZATION);
            if (StrUtil.isNotBlank(thirdSessionHeader)) {
                //获取缓存中的ThirdSession
                String key = CommonConstants.THIRD_SESSION_BEGIN + ":" + thirdSessionHeader;
                Object sessionObj = redisTemplate.opsForValue().get(key);
                if (sessionObj == null) {//session过期
                    ThirdSessionHolder.clear();
                } else {
                    String storeSessionStr = String.valueOf(sessionObj);
                    ThirdSession session = JSONUtil.toBean(storeSessionStr, ThirdSession.class);
                    ThirdSessionHolder.setThirdSession(session);
//                    redisTemplate.expire(key, CommonConstants.TIME_OUT_SESSION, TimeUnit.HOURS);//更新session过期时间
                }
            } else {
                ThirdSessionHolder.clear();
            }
            return Boolean.TRUE;
        }
    }


    /**
     * 校验session
     *
     * @param request
     * @param response
     * @return
     * @throws IOException
     */
    private boolean judeSession(HttpServletRequest request, HttpServletResponse response, ApiLogin apiLogin) throws IOException {
        //获取header中的ThirdSession
        String thirdSessionHeader = request.getHeader(CommonConstants.HEADER_AUTHORIZATION);
        if (StrUtil.isNotBlank(thirdSessionHeader)) {
            //获取缓存中的ThirdSession
            String key = CommonConstants.THIRD_SESSION_BEGIN + ":" + thirdSessionHeader;
            Object thirdSessionObj = redisTemplate.opsForValue().get(key);
            if (thirdSessionObj == null) {//session过期
                R r = R.failed(MyReturnCode.ERR_60001.getCode(), MyReturnCode.ERR_60001.getMsg());
                this.writerPrint(response, r);
                return Boolean.FALSE;
            } else {
                String sessionStr = String.valueOf(thirdSessionObj);
                ThirdSession session = JSONUtil.toBean(sessionStr, ThirdSession.class);
//                redisTemplate.expire(key, CommonConstants.TIME_OUT_SESSION, TimeUnit.HOURS);//更新session过期时间
                ThirdSessionHolder.setThirdSession(session);//设置thirdSession
                if (apiLogin != null && apiLogin.mustLogin()) {
                    //此接口必须登录商城才能访问
                    return this.judeSessionUserMall(response, session);
                } else {
                    return Boolean.TRUE;
                }
            }
        } else {
            R r = R.failed(MyReturnCode.ERR_60002.getCode(), MyReturnCode.ERR_60002.getMsg());
            this.writerPrint(response, r);
            return Boolean.FALSE;
        }
    }


    /**
     * 校验session是否商城登录
     *
     * @param thirdSession
     * @return
     * @throws IOException
     */
    private boolean judeSessionUserMall(HttpServletResponse response, ThirdSession thirdSession) throws IOException {
        String userId = thirdSession.getUserId();
        if (userId == null) {
            R r = R.failed(MyReturnCode.ERR_60003.getCode(), MyReturnCode.ERR_60003.getMsg());
            this.writerPrint(response, r);
            return Boolean.FALSE;
        }
        return Boolean.TRUE;
    }


    private void writerPrint(HttpServletResponse response, R r) throws IOException {
        //返回超时错误码，触发小程序重新登录
        response.setCharacterEncoding(CommonConstants.UTF8);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        PrintWriter writer = response.getWriter();
        writer.print(JSONUtil.parseObj(r));
        if (writer != null) {
            writer.close();
        }
    }
}
