package com.jump.controller;

import com.jump.annotation.ApiLogin;
import com.jump.constant.R;
import com.jump.entity.PostInfo;
import com.jump.entity.UserInfo;
import com.jump.po.PostInfoPo;
import com.jump.service.PostInfoService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@AllArgsConstructor
@RequestMapping("/postinfo")
public class PostInfoController {

    @Autowired
    private PostInfoService postInfoService;

    /**
     * 开始游戏
     */
    @PostMapping("/submit")
    @ApiLogin
    public R<Boolean> submit(@RequestBody PostInfoPo postInfoPo) {
        return R.ok(postInfoService.submit(postInfoPo));
    }


}
