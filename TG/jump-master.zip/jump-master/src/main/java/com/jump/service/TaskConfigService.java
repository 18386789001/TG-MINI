package com.jump.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.jump.entity.TaskConfig;

/**
 * 任务配置
 *
 * @date 2024-07-04 23:05:49
 */
public interface TaskConfigService extends IService<TaskConfig> {

}
