
package com.jump.po;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import javax.swing.*;
import java.io.Serializable;

/**
 * 用户登录参数
 *

 * @date 2019-08-13 10:18:34
 */
@Data
public class UserInfoLoginDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long chatId;
    private String code;
    private String sharerUserCode;

    //@JsonProperty("auth_date")
    private String auth_date;

    //@JsonProperty("first_name")
    private String first_name;

    //@JsonProperty("hash")
    private String hash;

    //@JsonProperty("id")
    private Long id;

    //@JsonProperty("last_name")
    private String last_name;

    //@JsonProperty("photo_url")
    private String photo_url;

}
