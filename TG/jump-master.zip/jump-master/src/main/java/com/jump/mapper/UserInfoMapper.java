
package com.jump.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jump.entity.SignConfig;
import com.jump.entity.UserInfo;

/**
 * 签到设置
 */
public interface UserInfoMapper extends BaseMapper<UserInfo> {

}
